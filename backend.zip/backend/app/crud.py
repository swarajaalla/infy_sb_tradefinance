# backend/app/crud.py
# backend/app/crud.py

from sqlalchemy.orm import Session
from . import models, schemas, auth as auth_utils


# ---------------------------------------------------------
# Get user by email
# ---------------------------------------------------------
def get_user_by_email(db: Session, email: str):
    return db.query(models.User).filter(models.User.email == email).first()


# ---------------------------------------------------------
# Create organisation if it does NOT exist
# ---------------------------------------------------------
def create_organisation_if_not_exists(db: Session, name: str):
    if not name:
        return None

    org = db.query(models.Organisation).filter(models.Organisation.name == name).first()
    if org:
        return org

    org = models.Organisation(name=name)
    db.add(org)
    db.commit()
    db.refresh(org)
    return org


# ---------------------------------------------------------
# Create user
# ---------------------------------------------------------
def create_user(db: Session, payload: schemas.UserCreate):
    # Check if email exists
    existing = get_user_by_email(db, payload.email)
    if existing:
        return None  # Handled in router

    # If org_name is given → create or get the organisation
    org = None
    if payload.org_name:
        org = create_organisation_if_not_exists(db, payload.org_name)

    # Hash password
    hashed = auth_utils.hash_password(payload.password)

    user = models.User(
        name=payload.name,
        email=payload.email,
        hashed_password=hashed,
        role=payload.role,
        org_id=org.id if org else None
    )

    db.add(user)
    db.commit()
    db.refresh(user)
    return user

