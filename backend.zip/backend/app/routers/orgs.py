# backend/app/routers/orgs.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from .. import schemas, models, crud
from ..deps import get_current_user

router = APIRouter(prefix="/orgs", tags=["orgs"])

@router.post("/", response_model=schemas.UserOut)
def create_org(data: dict, db: Session = Depends(get_db), user = Depends(get_current_user)):
    # only allow admin to create org
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Only admin can create orgs")
    name = data.get("name")
    if not name:
        raise HTTPException(status_code=400, detail="Missing name")
    org = crud.create_organisation_if_not_exists(db, name)
    return {"id": org.id, "name": org.name, "created_at": str(org.created_at)}
