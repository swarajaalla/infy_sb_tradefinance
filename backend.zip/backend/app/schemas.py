# backend/app/schemas.py
from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime
from enum import Enum

# --------------------------
# Roles
# --------------------------
class RoleEnum(str, Enum):
    admin = "admin"
    corporate = "corporate"
    bank = "bank"
    auditor = "auditor"

# --------------------------
# Organisation Schemas
# --------------------------
class OrganisationCreate(BaseModel):
    name: str

class OrganisationOut(BaseModel):
    id: int
    name: str
    created_at: datetime

    class Config:
        from_attributes = True   # Pydantic v2 equivalent of orm_mode

# --------------------------
# User Schemas
# --------------------------
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: RoleEnum
    org_name: Optional[str] = None   # matches your GitHub backend

    class Config:
        from_attributes = True
class UserOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    role: RoleEnum
    org_id: Optional[int]
    created_at: datetime

    class Config:
        from_attributes = True   # prevents orm_mode warnings

# --------------------------
# Token Schema
# --------------------------
class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
