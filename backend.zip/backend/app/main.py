# backend/app/main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import Base, engine
from .routers import auth as auth_router  # routers package must exist
from .routers import orgs as orgs_router

# create tables (dev only)
Base.metadata.create_all(bind=engine)

app = FastAPI(title="ChainDocs - Milestone 1")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router.router)
app.include_router(orgs_router.router)

