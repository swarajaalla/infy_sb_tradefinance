// frontend/register.js
async function register() {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;
    const orgName = document.getElementById("org").value;

    const payload = {
        name: name,
        email: email,
        password: password,
        role: role.toLowerCase(),
        org_name: orgName || null   // <-- correct name
    };

    try {
        const response = await fetch("http://127.0.0.1:8000/auth/register", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (!response.ok) {
            document.getElementById("error-msg").innerText = JSON.stringify(data.detail);
            return;
        }

        alert("Registration successful!");
        window.location.href = "index.html";

    } catch (error) {
        document.getElementById("error-msg").innerText = "Server error";
    }
}
