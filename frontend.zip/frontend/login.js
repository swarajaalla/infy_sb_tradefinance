// frontend/login.js
async function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  const form = new URLSearchParams();
  form.append("username", email); // OAuth2 expects username
  form.append("password", password);

  try {
    const res = await fetch("http://127.0.0.1:8000/auth/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: form.toString()
    });
    const data = await res.json();
    if (!res.ok) {
      document.getElementById("error-msg").innerText = data.detail || JSON.stringify(data);
      return;
    }
    localStorage.setItem("access_token", data.access_token);
    localStorage.setItem("refresh_token", data.refresh_token);
    alert("Login successful");
    // For now just show token in console
    console.log("Access token:", data.access_token);
  } catch (e) {
    document.getElementById("error-msg").innerText = "Server connection error";
  }
}

