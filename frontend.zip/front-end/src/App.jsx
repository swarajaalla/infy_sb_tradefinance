import { isLoggedIn } from "./auth";
import Login from "./pages/Login";
import Signup from "./pages/Signup";

export default function App() {
  return (
    <>
      {isLoggedIn() ? (
        <h1 className="text-2xl text-green-600 text-center mt-10">
          You are logged in 🎉
        </h1>
      ) : (
        <Login />
      )}
    </>
  );
}
