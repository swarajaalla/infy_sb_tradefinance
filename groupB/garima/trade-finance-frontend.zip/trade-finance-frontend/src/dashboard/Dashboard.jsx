import { useEffect, useState } from "react";
import axios from "axios";

// --- 1. STYLES (Sabse upar taaki 'ReferenceError' na aaye) ---
const styles = {
  fullScreenWrapper: { position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', display: 'flex', background: '#F8FAFC', zIndex: 9999 },
  sidebarStyle: { width: '280px', background: '#0F172A', color: 'white', padding: '30px 20px', display: 'flex', flexDirection: 'column' },
  logoSection: { display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '50px' },
  logoSquare: { background: '#3B82F6', width: '40px', height: '40px', borderRadius: '10px', display: 'flex', justifyContent: 'center', alignItems: 'center', fontWeight: 'bold' },
  logoText: { margin: 0, fontSize: '22px' },
  logoSubText: { margin: 0, fontSize: '11px', color: '#94A3B8' },
  navItem: { padding: '14px 18px', borderRadius: '12px', color: '#94A3B8', cursor: 'pointer', marginBottom: '5px' },
  activeNavItem: { background: '#1E293B', color: '#3B82F6', fontWeight: 'bold', padding: '14px 18px', borderRadius: '12px', cursor: 'pointer', marginBottom: '5px' },
  logoutBtn: { marginTop: 'auto', background: '#EF4444', color: 'white', border: 'none', padding: '12px', borderRadius: '10px', fontWeight: 'bold', cursor: 'pointer' },
  mainArea: { flex: 1, padding: '40px', overflowY: 'auto' },
  headerStyle: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '40px' },
  pageTitle: { margin: 0, fontSize: '32px', color: '#1E293B' },
  profileCard: { display: 'flex', alignItems: 'center', gap: '15px', background: 'white', padding: '10px 15px', borderRadius: '12px', boxShadow: '0 2px 5px rgba(0,0,0,0.05)' },
  avatarCircle: { width: '40px', height: '40px', background: '#3B82F6', borderRadius: '50%', color: 'white', display: 'flex', justifyContent: 'center', alignItems: 'center', fontWeight: 'bold' },
  pName: { display: 'block', fontWeight: 'bold', fontSize: '14px' },
  pEmail: { fontSize: '11px', color: '#64748B' },
  statsRow: { display: 'flex', gap: '20px', marginBottom: '30px' },
  statCard: { flex: 1, background: 'white', padding: '20px', borderRadius: '16px', boxShadow: '0 2px 10px rgba(0,0,0,0.02)' },
  contentCard: { background: 'white', borderRadius: '24px', padding: '30px', boxShadow: '0 4px 20px rgba(0,0,0,0.03)' },
  tableControls: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '25px' },
  btnNewTrade: { background: '#6366F1', color: 'white', border: 'none', padding: '10px 20px', borderRadius: '10px', fontWeight: 'bold', cursor: 'pointer' },
  tradeTable: { width: '100%', borderCollapse: 'collapse' },
  tableHeaderRow: { borderBottom: '1px solid #E2E8F0', textAlign: 'left' },
  thStyle: { padding: '15px', color: '#64748B', fontSize: '13px' },
  trStyle: { borderBottom: '1px solid #F1F5F9' },
  tdId: { fontWeight: 'bold', color: '#6366F1', padding: '15px' },
  tradeName: { fontWeight: 'bold', color: '#1E293B' },
  tradeAmount: { color: '#64748B', fontSize: '12px' },
  statusBadge: (s) => ({ 
    padding: '4px 10px', 
    borderRadius: '6px', 
    fontSize: '11px', 
    fontWeight: 'bold', 
    background: s === 'pending' ? '#FEF3C7' : s === 'submitted' ? '#DBEAFE' : '#D1FAE5', 
    color: s === 'pending' ? '#92400E' : s === 'submitted' ? '#1E40AF' : '#065F46' 
  }),
  btnOutline: { background: 'none', border: '1px solid #E2E8F0', padding: '6px 12px', borderRadius: '8px', cursor: 'pointer' },
  btnAction: { color: 'white', border: 'none', padding: '6px 15px', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer' },
  modalOverlay: { position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', background: 'rgba(0,0,0,0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 10001 },
  modalContent: { background: 'white', padding: '30px', borderRadius: '20px', width: '400px' },
  inputStyle: { width: '100%', padding: '12px', marginBottom: '15px', borderRadius: '10px', border: '1px solid #E2E8F0' },
  emptyState: { padding: '100px', textAlign: 'center', color: '#64748B', background: '#F8FAFC', width: '100vw', height: '100vh' }
};

export default function Dashboard() {
  // --- 2. STATES ---
  const [activeTab, setActiveTab] = useState("dashboard");
  const [trades, setTrades] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showTradeModal, setShowTradeModal] = useState(false);
  const [showDocModal, setShowDocModal] = useState(false);
  const [targetTradeId, setTargetTradeId] = useState("");
  const [newTrade, setNewTrade] = useState({ title: "", description: "", amount: "" });
  const [selectedFile, setSelectedFile] = useState(null);

  // --- 3. USER INFO ---
  const userRole = (localStorage.getItem("userRole") || "corporate").toLowerCase();
  const userName = localStorage.getItem("userName") || "User";
  const userEmail = localStorage.getItem("userEmail") || "user@chainedocs.io";
  const token = localStorage.getItem("token");

  // --- 4. API CALLS ---
  useEffect(() => { 
    if(token) {
      fetchTrades();
    } else {
      window.location.href = "/";
    }
  }, [token]);

  const fetchTrades = async () => {
    try {
      setLoading(true);
      const res = await axios.get("http://127.0.0.1:8000/trades/", {
        headers: { Authorization: `Bearer ${token}` }
      });
      setTrades(Array.isArray(res.data) ? res.data : []);
    } catch (err) { 
      console.error("Fetch error:", err);
      setTrades([]); 
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTrade = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://127.0.0.1:8000/trades/", {
        title: String(newTrade.title),
        description: String(newTrade.description || "No description"),
        amount: Number(newTrade.amount) 
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setShowTradeModal(false);
      setNewTrade({ title: "", description: "", amount: "" });
      fetchTrades();
      alert("Trade Created Successfully!");
    } catch (err) { 
      alert("Error: " + (err.response?.data?.detail || "Trade Creation Failed")); 
    }
  };

  const handleUploadDoc = async (e) => {
    e.preventDefault();
    if (!selectedFile) return alert("Pehle file select karein");
    const formData = new FormData();
    formData.append("file", selectedFile);
    formData.append("trade_id", targetTradeId);

    try {
      await axios.post("http://127.0.0.1:8000/documents/upload", formData, {
        headers: { 
          Authorization: `Bearer ${token}`, 
          "Content-Type": "multipart/form-data" 
        }
      });
      alert("Document Uploaded!");
      setShowDocModal(false);
      setSelectedFile(null);
      fetchTrades(); 
    } catch (err) { alert("Upload failed!"); }
  };

  const handleTradeAction = async (id, action) => {
    try {
      await axios.post(`http://127.0.0.1:8000/trades/${id}/${action}`, {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchTrades();
    } catch (err) { alert(err.response?.data?.detail || "Action failed"); }
  };

  // --- 5. RENDER HELPER ---
  const renderTable = () => (
    <section style={styles.contentCard}>
      <div style={styles.tableControls}>
        <h2 style={{ margin: 0 }}>Live Transactions</h2>
        {userRole === "corporate" && (
          <button onClick={() => setShowTradeModal(true)} style={styles.btnNewTrade}>+ New Trade</button>
        )}
      </div>
      <table style={styles.tradeTable}>
        <thead>
          <tr style={styles.tableHeaderRow}>
            <th style={styles.thStyle}>ID</th>
            <th style={styles.thStyle}>Details</th>
            <th style={styles.thStyle}>Status</th>
            <th style={styles.thStyle}>Verification</th>
            <th style={{...styles.thStyle, textAlign:'right'}}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {trades.length > 0 ? trades.map((trade) => (
            <tr key={trade.id} style={styles.trStyle}>
              <td style={styles.tdId}>#{trade.id}</td>
              <td>
                <div style={styles.tradeName}>{trade.title}</div>
                <div style={styles.tradeAmount}>${Number(trade.amount || 0).toLocaleString()}</div>
              </td>
              <td><span style={styles.statusBadge(trade.status)}>{trade.status}</span></td>
              <td>
                  {trade.has_documents ? 
                      <span style={{color:'#10B981', fontWeight:'bold'}}>✓ Linked</span> : 
                      <span style={{color:'#EF4444', fontWeight:'bold'}}>✗ Missing</span>
                  }
              </td>
              <td style={{ textAlign: 'right' }}>
                <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
                  {userRole === "corporate" && trade.status === "pending" && (
                    <>
                      <button onClick={() => {setTargetTradeId(trade.id); setShowDocModal(true)}} style={styles.btnOutline}>Upload</button>
                      <button 
                        onClick={() => handleTradeAction(trade.id, "submit")} 
                        disabled={!trade.has_documents} 
                        style={{...styles.btnAction, background: trade.has_documents ? '#3B82F6' : '#94A3B8'}}
                      >Submit</button>
                    </>
                  )}
                  {userRole === "bank" && trade.status === "submitted" && (
                    <>
                      <button onClick={() => handleTradeAction(trade.id, "approve")} style={{...styles.btnAction, background: '#10B981'}}>Approve</button>
                      <button onClick={() => handleTradeAction(trade.id, "reject")} style={{...styles.btnAction, background: '#EF4444'}}>Reject</button>
                    </>
                  )}
                </div>
              </td>
            </tr>
          )) : (
            <tr><td colSpan="5" style={{padding: '20px', textAlign: 'center'}}>No trades found.</td></tr>
          )}
        </tbody>
      </table>
    </section>
  );

  if (loading) return <div style={styles.emptyState}><h2>Syncing with Blockchain...</h2></div>;

  return (
    <div style={styles.fullScreenWrapper}>
      {/* SIDEBAR */}
      <aside style={styles.sidebarStyle}>
        <div style={styles.logoSection}>
          <div style={styles.logoSquare}>C</div>
          <div><h2 style={styles.logoText}>ChainDocs</h2><p style={styles.logoSubText}>Blockchain Platform</p></div>
        </div>
        <nav style={{ flex: 1 }}>
          <div onClick={() => setActiveTab("dashboard")} style={activeTab === "dashboard" ? styles.activeNavItem : styles.navItem}>📊 Dashboard</div>
          <div onClick={() => setActiveTab("trades")} style={activeTab === "trades" ? styles.activeNavItem : styles.navItem}>⇅ Trades</div>
          <div onClick={() => setActiveTab("integrity")} style={activeTab === "integrity" ? styles.activeNavItem : styles.navItem}>🛡️ Integrity Audit</div>
        </nav>
        <button style={styles.logoutBtn} onClick={() => {localStorage.clear(); window.location.href='/';}}>Logout</button>
      </aside>

      {/* MAIN CONTENT */}
      <main style={styles.mainArea}>
        <header style={styles.headerStyle}>
          <div>
            <h1 style={styles.pageTitle}>{activeTab.toUpperCase()}</h1>
            <p style={{margin:0, color:'#64748B'}}>Welcome back, {userName} ({userRole})</p>
          </div>
          <div style={styles.profileCard}>
             <div style={{textAlign:'right'}}><span style={styles.pName}>{userName}</span><span style={styles.pEmail}>{userEmail}</span></div>
             <div style={styles.avatarCircle}>{userName[0]}</div>
          </div>
        </header>

        {activeTab === "dashboard" && (
          <>
            <div style={styles.statsRow}>
              <div style={styles.statCard}><h4>Total Trades</h4><p>{trades.length}</p></div>
              <div style={styles.statCard}><h4>Pending</h4><p>{trades.filter(t => t.status === 'pending').length}</p></div>
              <div style={styles.statCard}><h4>Approved</h4><p style={{color:'#10B981'}}>{trades.filter(t => t.status === 'approved').length}</p></div>
            </div>
            {renderTable()}
          </>
        )}

        {activeTab === "trades" && renderTable()}

        {activeTab === "integrity" && (
          <section style={styles.contentCard}>
            <div style={{ textAlign: 'center', padding: '40px' }}>
              <h2 style={{ color: '#1E293B' }}>🛡️ Blockchain Integrity Audit</h2>
              <div style={{ border: '2px dashed #CBD5E1', padding: '40px', borderRadius: '20px', background: '#F8FAFC' }}>
                <input type="file" onChange={(e) => setSelectedFile(e.target.files[0])} style={{ marginBottom: '20px' }} />
                <br/>
                <input type="text" placeholder="Enter Trade ID" style={{...styles.inputStyle, width: '50%'}} onChange={(e) => setTargetTradeId(e.target.value)} />
                <button onClick={() => alert("Checking Blockchain Integrity...")} style={{ ...styles.btnNewTrade, width: '50%', display: 'block', margin: '10px auto' }}>
                  Verify on Blockchain
                </button>
              </div>
            </div>
          </section>
        )}
      </main>

      {/* MODALS */}
      {showTradeModal && (
        <div style={styles.modalOverlay}>
          <div style={styles.modalContent}>
            <h3>Initialize Trade</h3>
            <form onSubmit={handleCreateTrade}>
              <input style={styles.inputStyle} placeholder="Title" required value={newTrade.title} onChange={e => setNewTrade({...newTrade, title: e.target.value})} />
              <input style={styles.inputStyle} placeholder="Description" value={newTrade.description} onChange={e => setNewTrade({...newTrade, description: e.target.value})} />
              <input style={styles.inputStyle} type="number" placeholder="Amount (USD)" required value={newTrade.amount} onChange={e => setNewTrade({...newTrade, amount: e.target.value})} />
              <div style={{display:'flex', gap:10}}><button type="submit" style={styles.btnNewTrade}>Create</button><button type="button" onClick={() => setShowTradeModal(false)} style={styles.btnOutline}>Cancel</button></div>
            </form>
          </div>
        </div>
      )}

      {showDocModal && (
        <div style={styles.modalOverlay}>
          <div style={styles.modalContent}>
            <h3>Upload to Trade #{targetTradeId}</h3>
            <form onSubmit={handleUploadDoc}>
              <input type="file" style={styles.inputStyle} onChange={e => setSelectedFile(e.target.files[0])} required />
              <div style={{display:'flex', gap:10}}><button type="submit" style={styles.btnNewTrade}>Upload</button><button type="button" onClick={() => setShowDocModal(false)} style={styles.btnOutline}>Cancel</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
