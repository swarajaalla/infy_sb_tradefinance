import { getUserRole } from "../../utils/role";

export const getUserRole = () => {
  return localStorage.getItem("role");
};
