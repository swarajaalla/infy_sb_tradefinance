// src/utils/auth.js

export const getToken = () => {
  return localStorage.getItem("token");
};

export const isLoggedIn = () => {
  return !!localStorage.getItem("token");
};

export const getUserRole = () => {
  const token = getToken();
  if (!token) return null;

  try {
    // Decoding the JWT payload to get the role
    const payload = JSON.parse(atob(token.split(".")[1]));
    return payload.role; // returns: 'admin', 'bank', or 'corporate'
  } catch (e) {
    // Fallback: check localStorage user object if JWT decode fails
    const user = JSON.parse(localStorage.getItem("user") || "{}");
    return user.role || null;
  }
};

// THE MISSING PIECE: Properly exported logout function
export const logout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  localStorage.removeItem("theme"); // Optional: clear theme on logout
  window.location.href = "/"; // Force redirect to login page
};



