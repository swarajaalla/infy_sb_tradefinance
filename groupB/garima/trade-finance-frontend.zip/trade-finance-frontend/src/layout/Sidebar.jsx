import { Link } from "react-router-dom";

export default function Sidebar() {
  return (
    <div
      style={{
        width: "230px",
        background: "#0f2027",
        color: "#fff",
        padding: "20px",
      }}
    >
      <h2 style={{ marginBottom: "30px" }}>ChainDocs</h2>

      <nav style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
        <Link to="/app" style={linkStyle}>Dashboard</Link>
        <Link to="/app/documents" style={linkStyle}>Documents</Link>
        <Link to="/app/documents/upload" style={linkStyle}>Upload Document</Link>
        <Link to="/app/ledger/verify" style={linkStyle}>Ledger Verify</Link>
        <Link to="/integrity">Integrity Status</Link>
      </nav>
    </div>
  );
}

const linkStyle = {
  color: "#fff",
  textDecoration: "none",
  fontSize: "15px",
};


