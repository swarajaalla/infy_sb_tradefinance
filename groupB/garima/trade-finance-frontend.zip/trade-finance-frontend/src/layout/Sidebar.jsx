import { Link, useLocation, useNavigate } from "react-router-dom";
import { 
  LayoutDashboard, FileText, UploadCloud, Database, 
  ShieldAlert, TrendingUp, LogOut, Sun, Moon, Users 
} from "lucide-react";
import { useTheme } from "../context/ThemeContext";

export default function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();
  
  const userRole = (localStorage.getItem("userRole") || "corporate").toLowerCase();

  // Role-based Menu Filtering
  const allMenuItems = [
    { name: "Dashboard", icon: <LayoutDashboard size={20} />, path: "/dashboard", roles: ["corporate", "bank", "auditor", "admin"] },
    { name: "Documents", icon: <FileText size={20} />, path: "/documents", roles: ["corporate", "bank", "auditor"] },
    { name: "Upload", icon: <UploadCloud size={20} />, path: "/upload", roles: ["corporate"] },
    { name: "Ledger Explorer", icon: <Database size={20} />, path: "/ledger", roles: ["corporate", "bank", "auditor", "admin"] },
    { name: "Audit Logs", icon: <ShieldAlert size={20} />, path: "/integrity", roles: ["auditor", "admin"] },
    { name: "User Management", icon: <Users size={20} />, path: "/users", roles: ["admin"] },
    { name: "Risk Analysis", icon: <TrendingUp size={20} />, path: "/risk", roles: ["bank", "auditor"] },
  ];

  const filteredMenu = allMenuItems.filter(item => item.roles.includes(userRole));

  const handleLogout = () => {
    localStorage.clear();
    navigate("/login");
  };

  const sidebarBg = theme === "dark" ? "#0f172a" : "#ffffff";
  const textColor = theme === "dark" ? "#94a3b8" : "#64748b";

  return (
    <aside style={{ ...sidebarStyle, background: sidebarBg }}>
      <div style={logoStyle}>
        <div style={logoIcon}>C</div>
        <span style={{ color: theme === "dark" ? "white" : "#0f172a" }}>ChainDocs</span>
      </div>

      <nav style={{ flex: 1 }}>
        {filteredMenu.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link key={item.name} to={item.path} style={{
                ...linkStyle,
                backgroundColor: isActive ? "#3b82f6" : "transparent",
                color: isActive ? "white" : textColor,
              }}>
              <span style={{ display: "flex", alignItems: "center" }}>{item.icon}</span>
              <span style={{ marginLeft: "12px", fontWeight: isActive ? "600" : "500" }}>{item.name}</span>
            </Link>
          );
        })}
      </nav>

      <div style={{ marginTop: "auto", borderTop: "1px solid #e2e8f0", paddingTop: "20px" }}>
        <button onClick={toggleTheme} style={{ ...actionBtn, color: textColor }}>
          {theme === "dark" ? <Sun size={20} /> : <Moon size={20} />}
          <span style={{ marginLeft: "12px" }}>{theme === "dark" ? "Light" : "Dark"} Mode</span>
        </button>
        <button onClick={handleLogout} style={{ ...actionBtn, color: "#ef4444" }}>
          <LogOut size={20} />
          <span style={{ marginLeft: "12px" }}>Sign Out</span>
        </button>
      </div>
    </aside>
  );
}

const sidebarStyle = { width: "260px", height: "100vh", display: "flex", flexDirection: "column", padding: "24px 16px", position: "fixed", left: 0, top: 0, borderRight: "1px solid #e2e8f0", boxSizing: "border-box", zIndex: 1000 };
const logoStyle = { display: "flex", alignItems: "center", gap: "12px", fontSize: "22px", fontWeight: "bold", marginBottom: "40px", paddingLeft: "8px" };
const logoIcon = { width: "32px", height: "32px", background: "#3b82f6", borderRadius: "8px", color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "18px" };
const linkStyle = { display: "flex", alignItems: "center", padding: "12px 16px", borderRadius: "12px", textDecoration: "none", marginBottom: "4px", transition: "all 0.2s ease", fontSize: "15px" };
const actionBtn = { display: "flex", alignItems: "center", width: "100%", padding: "12px 16px", background: "none", border: "none", cursor: "pointer", fontSize: "15px" };



