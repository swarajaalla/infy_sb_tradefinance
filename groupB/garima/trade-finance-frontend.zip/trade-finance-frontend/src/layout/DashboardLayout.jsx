import { Outlet } from "react-router-dom";

export default function DashboardLayout() {
  return (
    <div
      className="dashboard-main-container"
      style={{
        marginLeft: "260px",
        width: "calc(100% - 260px)",
        minHeight: "100vh",
        padding: "30px",
        boxSizing: "border-box",
        display: "flex",
        flexDirection: "column",
        gap: "20px",
      }}
    >
      <Outlet /> {/* ✅ REQUIRED */}
    </div>
  );
}




