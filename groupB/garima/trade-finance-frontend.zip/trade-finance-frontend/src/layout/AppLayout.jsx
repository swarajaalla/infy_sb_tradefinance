import React, { useEffect, useState } from "react";
import { Outlet, Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { getToken, logout } from "../utils/auth"; // Error was here

export default function AppLayout() {
  const [criticalAlerts, setCriticalAlerts] = useState(0);
  const [isDark, setIsDark] = useState(localStorage.getItem("theme") === "dark");
  const navigate = useNavigate();

  // GLOBAL THEME: Apply to the <html> tag for total coverage
  useEffect(() => {
    const root = window.document.documentElement;
    if (isDark) {
      root.style.backgroundColor = "#111827";
      root.style.color = "#ffffff";
      localStorage.setItem("theme", "dark");
    } else {
      root.style.backgroundColor = "#ffffff";
      root.style.color = "#000000";
      localStorage.setItem("theme", "light");
    }
  }, [isDark]);

  useEffect(() => {
    const checkAlerts = async () => {
      try {
        const res = await axios.get("http://127.0.0.1:8000/integrity/alerts", {
          headers: { Authorization: `Bearer ${getToken()}` }
        });
        setCriticalAlerts(res.data.length);
      } catch (e) { console.error("Alert check failed"); }
    };
    checkAlerts();
    const id = setInterval(checkAlerts, 15000);
    return () => clearInterval(id);
  }, []);

  return (
    <div style={{ display: "flex", minHeight: "100vh", width: "100vw" }}>
      {/* SIDEBAR - Fixed Width and Position */}
      <aside style={{ 
        width: "260px", 
        borderRight: "1px solid #444", 
        padding: "25px", 
        display: "flex", 
        flexDirection: "column",
        backgroundColor: isDark ? "#1f2937" : "#f3f4f6" 
      }}>
        <h2 style={{ color: "#3b82f6", marginBottom: "40px" }}>TradeFlow Explorer</h2>
        
        <nav style={{ display: "flex", flexDirection: "column", gap: "20px", flex: 1 }}>
          <Link to="/dashboard" style={{ textDecoration: "none", color: "inherit", fontWeight: "500" }}>📊 Dashboard</Link>
          <Link to="/documents" style={{ textDecoration: "none", color: "inherit", fontWeight: "500" }}>📂 Documents</Link>
          <Link to="/ledger" style={{ textDecoration: "none", color: "inherit", fontWeight: "500" }}>⛓️ Ledger</Link>
          <Link to="/integrity" style={{ textDecoration: "none", color: "inherit", fontWeight: "500" }}>🛡️ Integrity Audit</Link>
        </nav>

        <div style={{ marginTop: "auto", paddingTop: "20px", borderTop: "1px solid #ddd" }}>
          <button 
            onClick={() => setIsDark(!isDark)}
            style={{ width: "100%", padding: "10px", cursor: "pointer", marginBottom: "10px", borderRadius: "6px" }}
          >
            {isDark ? "☀️ Light Mode" : "🌙 Dark Mode"}
          </button>
          <button 
            onClick={logout} 
            style={{ width: "100%", padding: "10px", background: "#ef4444", color: "white", border: "none", borderRadius: "6px", cursor: "pointer" }}
          >
            Logout
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
        {criticalAlerts > 0 && (
          <div style={{ backgroundColor: '#dc2626', color: 'white', padding: '15px', textAlign: 'center', fontWeight: 'bold' }}>
            ⚠️ CRITICAL: {criticalAlerts} Integrity Mismatches Detected! 
            <Link to="/integrity" style={{ color: 'white', marginLeft: "10px" }}>[Review Audit]</Link>
          </div>
        )}
        <main style={{ padding: "30px", flex: 1 }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
