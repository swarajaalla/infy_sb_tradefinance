import { Navigate } from "react-router-dom";
import { getUserRole, isLoggedIn } from "../utils/auth";

export default function ProtectedRoute({ allowedRoles, children }) {
  const role = getUserRole();

  if (!isLoggedIn()) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(role)) {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
}

