import api from "./axios";

export const createTrade = async (tradeData) => {
  const res = await api.post("/trades/", tradeData);
  return res.data;
};

export const submitTrade = async (tradeId) => {
  const res = await api.post(`/trades/${tradeId}/submit`);
  return res.data;
};
