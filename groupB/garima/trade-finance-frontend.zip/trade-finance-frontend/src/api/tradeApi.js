import api from "./axios";

export const createTrade = async (tradeData) => {
  const res = await api.post("/trades/", tradeData);
  return res.data;
};

export const submitTrade = async (tradeId) => {
  const res = await api.post(`/trades/${tradeId}/submit`);
  return res.data;
};


export const verifyTrade = (tradeId) => {
  return api.post(`/trades/${tradeId}/verify`);
};

export const approveTrade = (tradeId) => {
  return api.post(`/trades/${tradeId}/approve`);
};

export const rejectTrade = (id, reason) =>
  api.post(`/trades/${id}/reject`, null, {
    params: { reason },
  });
  
export const settleTrade = (tradeId) => {
  return api.post(`/trades/${tradeId}/settle`);
};