import api from "./axios";

export const uploadDocument = async (formData) => {
  const res = await api.post("/documents/upload", formData);
  return res.data;
};