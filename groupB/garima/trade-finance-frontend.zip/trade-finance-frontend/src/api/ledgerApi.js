import axios from "axios";

const API = "http://127.0.0.1:8000";

const authHeader = () => ({
  headers: {
    Authorization: `Bearer ${localStorage.getItem("token")}`,
  },
});

export const getIntegritySummary = async () => {
  const res = await axios.get(
    `${API}/ledger/integrity/summary`,
    authHeader()
  );
  return res.data;
};

export const getIntegrityAlerts = async () => {
  const res = await axios.get(
    `${API}/ledger/integrity/alerts`,
    authHeader()
  );
  return res.data;
};

export const getTradeLedger = (tradeId) => {
  return api.get(`/ledger/trade/${tradeId}`);
};

export const getLedgerSummary = () =>
  api.get("/ledger/integrity/summary");

export const getLedgerAlerts = () =>
  api.get("/ledger/integrity/alerts");