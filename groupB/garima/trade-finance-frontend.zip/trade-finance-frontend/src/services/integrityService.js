import axios from "axios";

const API = "http://127.0.0.1:8000";

export const getIntegritySummary = async () => {
  const token = localStorage.getItem("token");
  const res = await axios.get(`${API}/ledger/integrity/summary`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.data;
};

export const getIntegrityAlerts = async () => {
  const token = localStorage.getItem("token");
  const res = await axios.get(`${API}/ledger/integrity/alerts`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.data;
};