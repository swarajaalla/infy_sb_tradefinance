import axios from 'axios';

const API_BASE = "http://localhost:8000"; // Adjust to your FastAPI port

export const TradeService = {
  // Milestone 3: Trade Workflow
  getTrades: () => axios.get(`${API_BASE}/trades/`),
  
  updateTradeStatus: (tradeId, action) => 
    axios.post(`${API_BASE}/trades/${tradeId}/${action}`), // action: 'approve' | 'reject' | 'verify'

  // Milestone 3: Integrity & Alerts
  getIntegrityStatus: () => axios.get(`${API_BASE}/integrity/status`),
  
  getIntegrityAlerts: () => axios.get(`${API_BASE}/integrity/alerts`),

  runManualCheck: () => axios.post(`${API_BASE}/integrity/check`)
};