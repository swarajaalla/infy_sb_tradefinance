import { Routes, Route, Navigate } from "react-router-dom";
import ProtectedRoute from "./routes/ProtectedRoute";

import Login from "./auth/Login";
import Register from "./auth/Register";
import AppLayout from "./layout/AppLayout";

import Dashboard from "./dashboard/Dashboard";
import DocumentList from "./pages/Documents/DocumentList";
import LedgerExplorer from "./pages/Ledger/LedgerExplorer";
import IntegrityDashboard from "./pages/Integrity/IntegrityDashboard";

export default function App() {
  return (
    <Routes>
      {/* PUBLIC */}
      <Route path="/" element={<Login />} />
      <Route path="/register" element={<Register />} />

      {/* PROTECTED */}
      <Route element={<ProtectedRoute />}>
        <Route element={<AppLayout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/documents" element={<DocumentList />} />
          <Route path="/ledger" element={<LedgerExplorer />} />

          <Route
            path="/integrity"
            element={
              <ProtectedRoute allowedRoles={["ADMIN", "BANK"]} />
            }
          >
            <Route index element={<IntegrityDashboard />} />
          </Route>
        </Route>
      </Route>

      {/* FALLBACK */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}



















