import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./auth/Login";
import DashboardLayout from "./layout/DashboardLayout";
import Dashboard from "./pages/Dashboard";
import DocumentList from "./pages/Documents/DocumentList";
import UploadDocument from "./pages/Documents/UploadDocument";
import VerifyLedger from "./pages/Ledger/VerifyLedger";
import IntegrityStatus from "./pages/IntegrityStatus";

export default function App() {
  return (
    
      <Routes>
        {/* Public */}
        <Route path="/" element={<Login />} />

        {/* Protected Layout */}
        <Route path="/app" element={<DashboardLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="documents" element={<DocumentList />} />
          <Route path="documents/upload" element={<UploadDocument />} />
          <Route path="ledger/verify" element={<VerifyLedger />} />
          <Route path="integrity" element={<IntegrityStatus />} />
        </Route>
      </Routes>
    
  );
}










