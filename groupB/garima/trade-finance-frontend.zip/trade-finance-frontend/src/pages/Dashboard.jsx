export default function Dashboard() {
  return <h1>Trade Finance Dashboard</h1>;
}

