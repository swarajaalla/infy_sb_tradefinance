import IntegrityCards from "../pages/Integrity/IntegrityCards";
import LedgerExplorer from "../pages/Ledger/LedgerExplorer";
import DocumentList from "../pages/Documents/DocumentList";

export default function Dashboard() {
  return (
    <div style={{ padding: 20, display: "grid", gap: 20 }}>
      <IntegrityCards />
      <LedgerExplorer />
      <DocumentList />
    </div>
  );
}

