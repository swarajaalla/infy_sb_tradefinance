import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const CreateTrade = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const navigate = useNavigate();

  const handleCreate = async () => {
    try {
      const token = localStorage.getItem("token");
      // Fixed URL: hataya '/create' kyunki backend sirf '/trades/' use karta hai
      await axios.post(
        "http://127.0.0.1:8000/trades/", 
        {
          title,
          description,
          amount: Number(amount),
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      alert("✅ Trade created successfully");
      navigate("/dashboard"); // Redirect to dashboard
    } catch (error) {
      console.error(error);
      alert("❌ Failed to create trade: " + (error.response?.data?.detail || "Error"));
    }
  };

  return (
    <div style={{ padding: "40px", color: "white", background: "#1a1a1a", minHeight: "100vh" }}>
      <h2>Create New Trade</h2>
      <div style={{ display: "flex", flexDirection: "column", maxWidth: "300px", gap: "10px" }}>
        <input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} style={inputStyle} />
        <input placeholder="Description" value={description} onChange={(e) => setDescription(e.target.value)} style={inputStyle} />
        <input placeholder="Amount" type="number" value={amount} onChange={(e) => setAmount(e.target.value)} style={inputStyle} />
        <button onClick={handleCreate} style={buttonStyle}>Submit Trade</button>
      </div>
    </div>
  );
};

const inputStyle = { padding: "10px", borderRadius: "5px", border: "none" };
const buttonStyle = { padding: "10px", background: "#4caf50", color: "white", cursor: "pointer", border: "none" };

export default CreateTrade;


