import { useState } from "react";
import { createTrade } from "../../api/tradeApi";

function CreateTrade() {
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");

  const handleCreate = async () => {
    await createTrade({
      title,
      description: "Test trade",
      amount,
    });
    alert("Trade created");
  };

  return (
    <div>
      <h2>Create Trade</h2>

      <input placeholder="Title" onChange={(e) => setTitle(e.target.value)} />
      <input placeholder="Amount" onChange={(e) => setAmount(e.target.value)} />

      <button onClick={handleCreate}>Create</button>
    </div>
  );
}

export default CreateTrade;
