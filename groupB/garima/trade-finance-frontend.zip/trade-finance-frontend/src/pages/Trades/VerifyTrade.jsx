import axios from "axios";
import { useParams } from "react-router-dom";

function VerifyTrade() {
  const { tradeId } = useParams();

  const verifyTrade = async () => {
    const token = localStorage.getItem("token");

    await axios.post(
      `http://127.0.0.1:8000/trades/${tradeId}/verify`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    alert("Trade verified successfully");
  };

  return (
    <div>
      <h3>Trade Verification</h3>
      <button onClick={verifyTrade}>Verify Trade</button>
    </div>
  );
}

export default VerifyTrade;