import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
import TradeProgress from "../../components/TradeProgress";
import PageWrapper from "../../components/PageWrapper";
import TradeActions from "../../components/TradeActions";
import { getUserRole } from "../../utils/auth";


export default function TradeDetail() {
  const { id } = useParams();
  const [trade, setTrade] = useState(null);
  const token = localStorage.getItem("token");

  const fetchTrade = async () => {
    const res = await axios.get(`http://127.0.0.1:8000/trades/${id}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    setTrade(res.data);
  };

  useEffect(() => {
    fetchTrade();
  }, []);

  if (!trade) return <p>Loading...</p>;

  return (
    <PageWrapper>
      <h2>{trade.title}</h2>
      <p>{trade.description}</p>
      <p>Amount: ₹{trade.amount}</p>

      <TradeProgress status={trade.status} />

      {/* ✅ SINGLE SOURCE OF ACTION BUTTONS */}
      <TradeActions trade={trade} refresh={fetchTrade} />
    </PageWrapper>
  );
}


