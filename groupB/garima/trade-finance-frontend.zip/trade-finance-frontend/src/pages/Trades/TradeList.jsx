import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import PageWrapper from "../../components/PageWrapper";
import TradeProgress from "../../components/TradeProgress";

const TradeList = () => {
  const [trades, setTrades] = useState([]);
  const token = localStorage.getItem("token");
  const role = localStorage.getItem("role"); // 'bank' or 'corporate'
  const navigate = useNavigate();

  const fetchTrades = async () => {
    try {
      const res = await axios.get("http://127.0.0.1:8000/trades/", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setTrades(res.data);
    } catch (err) {
      console.error("Fetch error:", err);
    }
  };

  useEffect(() => { fetchTrades(); }, []);

  const handleAction = async (id, action) => {
    try {
      await axios.post(`http://127.0.0.1:8000/trades/${id}/${action}`, {}, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert(`Trade ${action}ed successfully`);
      fetchTrades();
    } catch (err) {
      alert(`Action failed: ${err.response?.data?.detail}`);
    }
  };

  return (
    <PageWrapper>
      <div style={{ padding: "20px", color: "white" }}>
        <h2>Trade Asset Explorer</h2>
        <div style={{ display: "grid", gap: "15px" }}>
          {trades.map((t) => (
            <div key={t.id} style={cardStyle}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <h3 onClick={() => navigate(`/app/trades/${t.id}`)} style={{ cursor: "pointer", color: "#4db8ff" }}>
                  {t.title}
                </h3>
                <span>ID: <b>{t.id}</b></span>
              </div>
              <p>{t.description}</p>
              <p>Amount: <b>${t.amount}</b> | Status: <span style={statusBadge}>{t.status}</span></p>
              
              <TradeProgress status={t.status} />

              <div style={{ marginTop: "15px" }}>
                {/* Bank Actions */}
                {role === "bank" && t.status === "submitted" && (
                  <button onClick={() => handleAction(t.id, "verify")} style={btnVerify}>Verify</button>
                )}
                {role === "bank" && t.status === "verified" && (
                  <button onClick={() => handleAction(t.id, "approve")} style={btnApprove}>Approve</button>
                )}
                {/* Corporate Info */}
                {role === "corporate" && t.status === "created" && (
                  <p style={{ fontSize: "12px", color: "#aaa" }}>Pending Document Upload for ID: {t.id}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </PageWrapper>
  );
};

// Styles
const cardStyle = { background: "#252525", padding: "20px", borderRadius: "10px", borderLeft: "5px solid #4db8ff" };
const statusBadge = { background: "#444", padding: "2px 8px", borderRadius: "4px", textTransform: "uppercase", fontSize: "12px" };
const btnVerify = { background: "#f39c12", color: "white", border: "none", padding: "8px 15px", borderRadius: "5px", cursor: "pointer" };
const btnApprove = { background: "#27ae60", color: "white", border: "none", padding: "8px 15px", borderRadius: "5px", cursor: "pointer", marginLeft: "10px" };

export default TradeList;

