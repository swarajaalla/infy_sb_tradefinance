import { useEffect, useState } from "react";
import {
  getIntegritySummary,
  getIntegrityAlerts
} from "../services/integrityService";

export default function IntegrityStatus() {
  const [summary, setSummary] = useState(null);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const s = await getIntegritySummary();
        const a = await getIntegrityAlerts();
        setSummary(s);
        setAlerts(a);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) return <h3>Loading integrity status...</h3>;

  return (
    <div>
      <h1>Document Integrity Status</h1>

      {/* SUMMARY CARDS */}
      <div style={{ display: "flex", gap: 20, marginTop: 20 }}>
        <Card title="Total Checks" value={summary.total} />
        <Card title="Passed" value={summary.passed} color="green" />
        <Card title="Failed" value={summary.failed} color="red" />
        <Card title="Pending" value={summary.pending} color="orange" />
        <Card title="Pass Rate" value={`${summary.pass_rate}%`} color="purple" />
      </div>

      {/* ALERTS */}
      <h2 style={{ marginTop: 40 }}>
        Alerts ({alerts.length})
      </h2>

      {alerts.length === 0 && <p>No integrity issues 🎉</p>}

      {alerts.map((a, i) => (
        <div
          key={i}
          style={{
            border: "1px solid #ddd",
            padding: 15,
            marginTop: 10,
            borderLeft: `5px solid ${
              a.severity === "HIGH" ? "red" : "orange"
            }`
          }}
        >
          <strong>{a.severity}</strong> — {a.type}
          <p>{a.message}</p>
          <small>
            Ref: {a.reference} | {new Date(a.created_at).toLocaleString()}
          </small>
        </div>
      ))}
    </div>
  );
}

function Card({ title, value, color }) {
  return (
    <div
      style={{
        flex: 1,
        padding: 20,
        borderRadius: 10,
        background: "#f9f9f9",
        borderTop: `4px solid ${color || "#333"}`
      }}
    >
      <h4>{title}</h4>
      <h2>{value}</h2>
    </div>
  );
}
