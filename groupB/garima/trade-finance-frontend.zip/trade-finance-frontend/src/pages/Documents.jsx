import { useState, useEffect } from "react";
import axios from "axios";
import { getToken } from "../utils/auth";
import DashboardLayout from "../layout/DashboardLayout";

export default function Documents() {
  const [docs, setDocs] = useState([]);
  const token = getToken();

  useEffect(() => {
    const fetchDocs = async () => {
      const res = await axios.get("http://127.0.0.1:8000/documents/", {
        headers: { Authorization: `Bearer ${token}` }
      });
      setDocs(res.data);
    };
    fetchDocs();
  }, []);

  return (
    <DashboardLayout>
      <div style={{padding: '20px', background: 'white', borderRadius: '20px'}}>
        <h2 style={{color: '#1e293b'}}>Secure Document Vault</h2>
        <table style={{width: '100%', borderCollapse: 'collapse', marginTop: '20px'}}>
          <thead>
            <tr style={{textAlign: 'left', borderBottom: '2px solid #eee', color: '#64748b'}}>
              <th>Type</th>
              <th>Doc Number</th>
              <th>Blockchain Hash</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {docs.map(doc => (
              <tr key={doc.id} style={{borderBottom: '1px solid #f9fafb', height: '50px'}}>
                <td><b>{doc.doc_type}</b></td>
                <td>{doc.doc_number}</td>
                <td style={{fontFamily: 'monospace', fontSize: '12px', color: '#6366f1'}}>{doc.hash}</td>
                <td><span style={{color: '#22c55e'}}>Verified ✅</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}