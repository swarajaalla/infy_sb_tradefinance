import React, { useEffect, useState } from "react";
import axios from "axios";
import { getToken } from "../../utils/auth";

export default function IntegrityAlerts() {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchAlerts = async () => {
    try {
      const res = await axios.get("http://127.0.0.1:8000/integrity/alerts", {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      setAlerts(res.data);
    } catch (err) {
      console.error("Failed to fetch alerts");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlerts();
    const interval = setInterval(fetchAlerts, 30000); // Auto-refresh every 30s
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h2>Security & Integrity Alerts</h2>
      {loading ? <p>Scanning ledger...</p> : (
        <div style={{ marginTop: "20px" }}>
          {alerts.length === 0 ? (
            <div style={{ color: "green", border: "1px solid green", padding: "15px" }}>
              ✅ All transactions are cryptographically secure. No tampering detected.
            </div>
          ) : (
            alerts.map((alert) => (
              <div key={alert.id} style={{ border: "1px solid red", padding: "15px", marginBottom: "10px", background: "#fff5f5" }}>
                <h4 style={{ color: "red", margin: 0 }}>⚠️ DATA TAMPERING DETECTED</h4>
                <p><strong>Trade ID:</strong> {alert.trade_id}</p>
                <p><strong>Mismatch Type:</strong> {alert.type} (Expected Hash vs Current Hash mismatch)</p>
                <button onClick={() => window.location.href=`/trades/${alert.trade_id}`}>Investigate Trade</button>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}