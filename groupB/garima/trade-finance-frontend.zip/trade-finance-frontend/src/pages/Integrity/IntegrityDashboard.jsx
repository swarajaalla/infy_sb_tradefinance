import { useEffect, useState } from "react";
import axios from "axios";
import { getToken } from "../../utils/auth";

export default function IntegrityDashboard() {
  const [mismatches, setMismatches] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMismatches = async () => {
      try {
        const res = await axios.get("http://127.0.0.1:8000/integrity/alerts", {
          headers: { Authorization: `Bearer ${getToken()}` }
        });
        setMismatches(res.data);
      } catch (err) {
        console.error("Failed to fetch detailed alerts");
      } finally {
        setLoading(false);
      }
    };
    fetchMismatches();
  }, []);

  return (
    <div style={{ padding: "30px" }}>
      <h1 style={{ fontSize: 24, fontWeight: "bold", color: "#b91c1c" }}>
        🛡️ Integrity Audit Logs
      </h1>
      <p style={{ marginBottom: 20 }}>Detailed list of hash mismatches and potential tampering detections.</p>

      {loading ? <p>Scanning Blockchain Ledger...</p> : (
        <div style={{ display: "grid", gap: "15px" }}>
          {mismatches.length === 0 ? (
            <div style={{ padding: "40px", textAlign: "center", background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: "8px" }}>
              <p style={{ color: "#166534", fontWeight: "bold" }}>✅ System Integrity Verified: No mismatches found.</p>
            </div>
          ) : (
            mismatches.map((alert) => (
              <div key={alert.id} style={{ padding: "20px", background: "#fef2f2", border: "1px solid #fee2e2", borderRadius: "8px", boxShadow: "0 2px 4px rgba(0,0,0,0.05)" }}>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ fontWeight: "bold", color: "#991b1b" }}>⚠️ Tampering Detected</span>
                  <span style={{ fontSize: "12px", color: "#666" }}>{new Date(alert.detected_at).toLocaleString()}</span>
                </div>
                <hr style={{ margin: "10px 0", borderColor: "#fecaca" }} />
                <p><strong>Trade ID:</strong> {alert.trade_id}</p>
                <p><strong>Document ID:</strong> {alert.document_id}</p>
                <p style={{ fontSize: "13px", fontFamily: "monospace", marginTop: "5px" }}>
                   <span style={{ color: "#166534" }}>Expected: {alert.expected_hash}</span><br/>
                   <span style={{ color: "#991b1b" }}>Found: {alert.actual_hash}</span>
                </p>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}