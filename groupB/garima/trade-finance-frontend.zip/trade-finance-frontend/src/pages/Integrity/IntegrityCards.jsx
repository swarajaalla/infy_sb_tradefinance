export default function IntegrityCards() {
  const cards = [
    { title: "Total Checks", value: 12, color: "#2563eb" },
    { title: "Passed", value: 10, color: "#16a34a" },
    { title: "Failed", value: 2, color: "#dc2626" },
  ];

  return (
    <div style={{ display: "flex", gap: 20 }}>
      {cards.map((c) => (
        <div
          key={c.title}
          style={{
            flex: 1,
            padding: 20,
            borderRadius: 12,
            background: c.color,
            color: "white",
          }}
        >
          <h3>{c.title}</h3>
          <p style={{ fontSize: 28, fontWeight: "bold" }}>{c.value}</p>
        </div>
      ))}
    </div>
  );
}




