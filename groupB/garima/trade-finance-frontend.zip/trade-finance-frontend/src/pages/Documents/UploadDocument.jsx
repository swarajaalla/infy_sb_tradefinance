import { useState } from "react";
import axios from "axios";

export default function UploadDocument() {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");

  const tradeId = 1; // 🔴 TEMP: later dynamic

  const upload = async () => {
    if (!file) {
      setMessage("Please select a file");
      return;
    }

    const token = localStorage.getItem("token");

    if (!token) {
      setMessage("❌ User not logged in");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    try {
      await axios.post(
        `http://127.0.0.1:8000/documents/upload/${tradeId}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setMessage("✅ Document uploaded successfully");
    } catch (err) {
      console.error(err);
      setMessage("❌ Upload failed");
    }
  };

  return (
    <div style={{ padding: 30 }}>
      <h2>Upload Document</h2>

      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <br /><br />
      <button onClick={upload}>Upload</button>

      <p>{message}</p>
    </div>
  );
}





