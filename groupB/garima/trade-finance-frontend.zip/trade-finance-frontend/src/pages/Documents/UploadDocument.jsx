import { useState } from "react";
import axios from "axios";

export default function UploadDocument() {
  const [file, setFile] = useState(null);
  const [tradeId, setTradeId] = useState(""); // Dynamic input
  const [message, setMessage] = useState("");

  const upload = async () => {
    if (!file || !tradeId) {
      setMessage("⚠️ Please select a file and enter Trade ID");
      return;
    }

    const token = localStorage.getItem("token");
    const formData = new FormData();
    formData.append("file", file); // Backend expects 'file'

    try {
      await axios.post(
        `http://127.0.0.1:8000/documents/upload/${tradeId}`,
        formData,
        {
          headers: {
            "Authorization": `Bearer ${token}`,
            "Content-Type": "multipart/form-data", // 👈 Very Important
          },
        }
      );
      setMessage("✅ Document uploaded successfully!");
    }  catch (err) {
  console.log("Error Details:", err.response?.data); // Ye console mein check karein
  setMessage(`❌ Upload failed: ${err.response?.data?.detail || "Check Console"}`);
}
  };

  return (
    <div style={{ padding: 30, color: "white" }}>
      <h2>Upload Trade Document</h2>
      <input type="number" placeholder="Enter Trade ID" value={tradeId} onChange={(e) => setTradeId(e.target.value)} style={{marginBottom: "10px", padding: "5px"}} />
      <br />
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <br /><br />
      <button onClick={upload} style={{padding: "10px 20px", cursor: "pointer"}}>Upload to Ledger</button>
      <p>{message}</p>
    </div>
  );
}




