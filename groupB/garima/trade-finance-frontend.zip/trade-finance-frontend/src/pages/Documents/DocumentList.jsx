import { useEffect, useState } from "react";
import axios from "axios";

export default function DocumentList() {
  const [docs, setDocs] = useState([]);

  useEffect(() => {
    const fetchDocs = async () => {
      const token = localStorage.getItem("token");

      const res = await axios.get(
        "http://127.0.0.1:8000/documents",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setDocs(res.data);
    };

    fetchDocs();
  }, []);

  return (
    <div style={{ padding: 30 }}>
      <h2>Documents</h2>

      <ul>
        {docs.map((d) => (
          <li key={d.id}>
            {d.filename} – {d.status}
          </li>
        ))}
      </ul>
    </div>
  );
}
