import { useEffect, useState } from "react";
import axios from "axios";
import { getToken } from "../../utils/auth";

export default function DocumentList() {
  const [docs, setDocs] = useState([]);
  const token = getToken();

  const fetchDocs = () => {
    axios
      .get("http://127.0.0.1:8000/documents/list", {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => setDocs(res.data))
      .catch(() => setDocs([]));
  };

  useEffect(() => {
    fetchDocs();
  }, []);

  // handleVerify logic for Milestone 3
  const handleVerify = async (docId) => {
    try {
      const res = await axios.post(
        `http://127.0.0.1:8000/integrity/verify-doc/${docId}`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      if (res.data.status === "VALID") {
        alert("✅ Integrity Confirmed: Document hash matches the Ledger.");
      } else {
        alert("⚠️ WARNING: Hash mismatch! Data may have been tampered with.");
      }
      fetchDocs(); // Refresh to see updated status
    } catch (err) {
      alert("Verification failed. Check if backend is running.");
    }
  };

  return (
    <div>
      <h2 style={{ marginBottom: 10 }}>Documents Repository</h2>

      <div style={{ display: "flex", gap: 16, marginBottom: 20 }}>
        <Card label="Total Documents" value={docs.length} />
        <Card label="Verified" value={docs.filter(d => d.status === "VERIFIED").length} />
      </div>

      <div style={{ background: "white", borderRadius: 12, padding: 16, color: "black" }}>
        {/* Table Header */}
        <div style={{ display: "flex", fontWeight: "bold", padding: "10px", borderBottom: "2px solid #eee" }}>
          <span style={{ flex: 2 }}>File Name</span>
          <span style={{ flex: 1 }}>Status</span>
          <span style={{ flex: 1 }}>Actions</span>
        </div>

        {docs.map((d) => (
          <div
            key={d.id}
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: 10,
              borderBottom: "1px solid #eee",
            }}
          >
            <span style={{ flex: 2 }}>{d.filename}</span>
            <span style={{ flex: 1 }}>
              <span style={{ 
                padding: "4px 8px", 
                borderRadius: "4px", 
                fontSize: "12px",
                background: d.status === "VERIFIED" ? "#dcfce7" : "#f3f4f6",
                color: d.status === "VERIFIED" ? "#166534" : "#374151"
              }}>
                {d.status}
              </span>
            </span>
            <span style={{ flex: 1 }}>
              <button 
                onClick={() => handleVerify(d.id)}
                style={{ 
                  color: "blue", 
                  background: "none", 
                  border: "none", 
                  cursor: "pointer", 
                  textDecoration: "underline", 
                  fontSize: "12px" 
                }}
              >
                Verify Hash
              </button>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function Card({ label, value }) {
  return (
    <div style={{ flex: 1, padding: 16, borderRadius: 12, background: "#e5e7eb", color: "black" }}>
      <p style={{ margin: 0, fontSize: "14px", color: "#4b5563" }}>{label}</p>
      <h3 style={{ margin: "5px 0 0 0" }}>{value}</h3>
    </div>
  );
}




