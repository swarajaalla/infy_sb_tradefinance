import { useEffect, useState } from "react";
import axios from "axios";

export default function AdminDashboard() {
  const [data, setData] = useState(null);
  const token = localStorage.getItem("token");

  useEffect(() => {
    axios.get("http://127.0.0.1:8000/admin/dashboard", {
      headers: { Authorization: `Bearer ${token}` },
    }).then(res => setData(res.data));
  }, []);

  if (!data) return <p>Loading...</p>;

  return (
    <div style={{ padding: 20 }}>
      <h2>Admin Dashboard</h2>

      <p>Total Trades: {data.total_trades}</p>
      <p>Ledger Entries: {data.ledger_entries}</p>
      <p>Documents: {data.documents}</p>

      <h4>Status</h4>
      {Object.entries(data.by_status).map(([k, v]) => (
        <p key={k}>{k}: {v}</p>
      ))}
    </div>
  );
}



