import { useState } from "react";
import axios from "axios";

export default function VerifyLedger() {
  const [id, setId] = useState("");
  const [result, setResult] = useState(null);

  const verify = async () => {
    const token = localStorage.getItem("token");

    if (!token) {
      setResult({ message: "User not logged in" });
      return;
    }

    try {
      const res = await axios.get(
        `http://127.0.0.1:8000/ledger/verify/TRADE/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setResult(res.data);
    } catch (err) {
      console.error(err);
      setResult({ message: "Verification failed" });
    }
  };

  return (
    <div style={{ padding: 30 }}>
      <h2>Ledger Verification</h2>

      <input
        placeholder="Trade ID"
        value={id}
        onChange={(e) => setId(e.target.value)}
      />
      <button onClick={verify}>Verify</button>

      {result && (
        <pre>{JSON.stringify(result, null, 2)}</pre>
      )}
    </div>
  );
}



