import { useEffect, useState } from "react";
import { getTradeLedger } from "../../api/ledgerApi";

export default function LedgerTimeline({ tradeId }) {
  const [entries, setEntries] = useState([]);

  useEffect(() => {
    if (tradeId) {
      getTradeLedger(tradeId).then((res) => setEntries(res.data));
    }
  }, [tradeId]);

  return (
    <div className="mt-6">
      <h3 className="font-semibold mb-2">Trade Timeline</h3>
      <ul className="border-l-2 border-gray-300 pl-4">
        {entries.map((e) => (
          <li key={e.id} className="mb-3">
            <div className="text-sm font-medium">{e.action}</div>
            <div className="text-xs text-gray-500">
              {new Date(e.created_at).toLocaleString()}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
