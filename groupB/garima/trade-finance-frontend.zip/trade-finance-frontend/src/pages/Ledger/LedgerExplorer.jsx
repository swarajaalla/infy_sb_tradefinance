import { useEffect, useState } from "react";
import axios from "axios";

export default function LedgerExplorer() {
  const [ledger, setLedger] = useState([]);

  useEffect(() => {
    axios
      .get("http://127.0.0.1:8000/ledger/explorer", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      })
      .then((res) => setLedger(res.data))
      .catch(console.error);
  }, []);

  return (
    <div
      style={{
        background: "white",
        padding: 24,
        borderRadius: 14,
        boxShadow: "0 8px 24px rgba(0,0,0,0.05)",
      }}
    >
      <h2 style={{ marginBottom: 16 }}>📜 Ledger Explorer</h2>

      {ledger.length === 0 && <p>No ledger records found</p>}

      {ledger.map((entry) => (
        <div
          key={entry.id}
          style={{
            padding: "14px 0",
            borderBottom: "1px solid #e5e7eb",
          }}
        >
          <div style={{ fontWeight: "600" }}>
            {entry.action} | {entry.entity_type} #{entry.entity_id}
          </div>

          <div style={{ fontSize: 13, color: "#6b7280" }}>
            Hash: {entry.hash?.slice(0, 30)}...
          </div>
        </div>
      ))}
    </div>
  );
}


