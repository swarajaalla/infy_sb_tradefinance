import axios from "axios";
import { getUserRole, getToken } from "../utils/auth";

const API = "http://127.0.0.1:8000";

export default function TradeActions({ trade, refresh }) {
  const role = getUserRole();

  const call = async (url, reason) => {
    try {
      await axios.post(
        API + url,
        {},
        {
          headers: { Authorization: `Bearer ${getToken()}` },
          params: reason ? { reason } : {},
        }
      );
      alert("Action Successful");
      refresh();
    } catch (err) {
      alert("Action failed: " + (err.response?.data?.detail || "Unknown error"));
    }
  };

  // MILESTONE 3 ADDITION: Manual Integrity Check
  const checkIntegrity = async () => {
    try {
      // Assuming your backend has this route from integrity_router.py
      const res = await axios.post(`${API}/integrity/check/${trade.id}`, {}, {
        headers: { Authorization: `Bearer ${getToken()}` }
      });
      alert(res.data.status === "VALID" ? "✅ Integrity Verified: No Tampering" : "⚠️ WARNING: Data Mismatch Detected!");
      refresh();
    } catch (err) {
      alert("Integrity check failed.");
    }
  };

  return (
    <div style={{ display: "flex", gap: "10px", marginTop: 20, flexWrap: "wrap" }}>
      
      {/* INTEGRITY CHECK - Available to all roles for transparency */}
      <button 
        style={{ background: "#6366f1", color: "white", padding: "8px 12px", borderRadius: "4px" }}
        onClick={checkIntegrity}
      >
        Verify Ledger Integrity
      </button>

      {/* SUBMIT */}
      {trade.status === "DOCUMENTS_UPLOADED" && role === "BANK" && (
        <button className="btn-primary" onClick={() => call(`/trades/${trade.id}/submit`)}>Submit</button>
      )}

      {/* VERIFY (Verifier Role) */}
      {trade.status === "SUBMITTED" && role === "VERIFIER" && (
        <>
          <button className="btn-success" onClick={() => call(`/trades/${trade.id}/verify`)}>Verify</button>
          <button style={{ background: "red", color: "white" }} onClick={() => call(`/trades/${trade.id}/reject`, prompt("Reject reason"))}>Reject</button>
        </>
      )}

      {/* APPROVE (Approver Role) */}
      {trade.status === "VERIFIED" && role === "APPROVER" && (
        <>
          <button style={{ background: "green", color: "white" }} onClick={() => call(`/trades/${trade.id}/approve`)}>Approve</button>
          <button style={{ background: "red", color: "white" }} onClick={() => call(`/trades/${trade.id}/reject`, prompt("Reject reason"))}>Reject</button>
        </>
      )}
    </div>
  );
}
