import { Navigate, Outlet } from "react-router-dom";
import { getUserRole } from "../utils/auth";

export default function ProtectedRoute({ allowedRoles }) {
  const token = localStorage.getItem("access_token");
  const role = getUserRole();

  if (!token) {
    return <Navigate to="/" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(role)) {
    return <Navigate to="/dashboard" replace />;
  }

  return <Outlet />; // ✅ IMPORTANT
}
