import { useEffect, useState } from "react";
import axios from "axios";
import { getToken } from "../utils/auth";

export default function LedgerSummary() {
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    axios
      .get("http://127.0.0.1:8000/ledger/integrity/summary", {
        headers: { Authorization: `Bearer ${getToken()}` },
      })
      .then((res) => setSummary(res.data));
  }, []);

  if (!summary) return <p>Loading ledger summary...</p>;

  return (
    <div style={{ border: "1px solid #ccc", padding: 16, marginBottom: 20 }}>
      <h3>Ledger Integrity</h3>
      <p>Total Entries: {summary.total}</p>
      <p>Passed: {summary.passed}</p>
      <p>Failed: {summary.failed}</p>
      <p>Pass Rate: {summary.pass_rate}%</p>

      {summary.failed === 0 ? (
        <p style={{ color: "green" }}>✔ Ledger Verified</p>
      ) : (
        <p style={{ color: "red" }}>⚠ Ledger Tampered</p>
      )}
    </div>
  );
}


