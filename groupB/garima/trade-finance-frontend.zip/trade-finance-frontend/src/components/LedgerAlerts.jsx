import { useEffect, useState } from "react";
import axios from "axios";

export default function LedgerAlerts() {
  const [alerts, setAlerts] = useState([]);
  const token = localStorage.getItem("token");

  useEffect(() => {
    axios
      .get("http://127.0.0.1:8000/ledger/integrity/alerts", {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => setAlerts(res.data));
  }, []);

  if (!alerts.length) return <p>No integrity alerts 🎉</p>;

  return (
    <div>
      <h3>Integrity Alerts</h3>
      {alerts.map((a) => (
        <div key={a.id} style={{ border: "1px solid red", margin: 8, padding: 8 }}>
          <b>{a.severity}</b> — {a.message}
        </div>
      ))}
    </div>
  );
}



