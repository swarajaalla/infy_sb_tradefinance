import React from 'react';

const IntegrityStatus = ({ status }) => {
  const isSecure = status === "VALID" || status === "VERIFIED";
  
  return (
    <div className={`flex items-center gap-2 p-2 rounded ${isSecure ? 'bg-green-100' : 'bg-red-100'}`}>
      <span className={`h-3 w-3 rounded-full ${isSecure ? 'bg-green-500' : 'bg-red-500 animate-pulse'}`}></span>
      <span className={`text-sm font-medium ${isSecure ? 'text-green-800' : 'text-red-800'}`}>
        {isSecure ? "Data Integrity Verified" : "SYSTEM ALERT: TAMPERING DETECTED"}
      </span>
    </div>
  );
};

export default IntegrityStatus;