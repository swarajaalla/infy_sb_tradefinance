const steps = ["CREATED", "VERIFIED", "APPROVED", "SETTLED"];

export default function TradeProgress({ status }) {
  const currentIndex = steps.indexOf(status);

  return (
    <div style={{ marginTop: 10 }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        {steps.map((step, index) => (
          <div
            key={step}
            style={{
              flex: 1,
              textAlign: "center",
              fontSize: "12px",
              color: index <= currentIndex ? "#16a34a" : "#9ca3af",
            }}
          >
            {step}
          </div>
        ))}
      </div>

      <div
        style={{
          height: 6,
          background: "#e5e7eb",
          borderRadius: 6,
          marginTop: 6,
        }}
      >
        <div
          style={{
            width: `${((currentIndex + 1) / steps.length) * 100}%`,
            height: "100%",
            background: "#16a34a",
            borderRadius: 6,
            transition: "width 0.4s",
          }}
        />
      </div>
    </div>
  );
}
