const statusColors = {
  CREATED: "bg-gray-200 text-gray-800",
  DOCUMENTS_UPLOADED: "bg-yellow-200 text-yellow-800",
  VERIFIED: "bg-blue-200 text-blue-800",
  APPROVED: "bg-green-200 text-green-800",
  SETTLED: "bg-purple-200 text-purple-800",
};

export default function TradeStatusBadge({ status }) {
  return (
    <span
      className={`px-3 py-1 rounded-full text-xs font-semibold ${statusColors[status]}`}
    >
      {status}
    </span>
  );
}