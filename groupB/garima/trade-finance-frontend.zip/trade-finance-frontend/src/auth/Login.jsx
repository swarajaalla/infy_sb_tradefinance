import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function Login() {
  const [formData, setFormData] = useState({
    username: "",
    name: "",
    email: "",
    password: "",
    role: "corporate",
    org_name: "",
  });

  const [isRegister, setIsRegister] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    const endpoint = isRegister ? "register" : "login";
    const fullURL = `http://127.0.0.1:8000/auth/${endpoint}`;

    try {
      if (isRegister) {
        // ✅ REGISTER → JSON
        const payload = {
          ...formData,
          username: formData.username || formData.email,
        };

        await axios.post(fullURL, payload);

        alert("Registration Successful! Please login.");
        setIsRegister(false);
        return;
      }

      // ✅ LOGIN → OAuth2PasswordRequestForm (FORM ENCODED STRING)
      const payload = `username=${encodeURIComponent(
        formData.email.trim()
      )}&password=${encodeURIComponent(formData.password)}`;

      const res = await axios.post(fullURL, payload, {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
      });

      // ✅ STORE TOKEN
      localStorage.setItem("access_token", res.data.access_token);
      localStorage.setItem("userRole", res.data.role || "corporate");
      localStorage.setItem(
        "userName",
        res.data.name || formData.email.split("@")[0]
      );

      navigate("/dashboard");
    } catch (err) {
      const detail = err.response?.data?.detail;

      if (Array.isArray(detail)) {
        setError(detail[0]?.msg || "Invalid credentials");
      } else if (typeof detail === "string") {
        setError(detail);
      } else {
        setError("Login failed. Please try again.");
      }
    }
  };

  return (
    <div style={containerStyle}>
      <div style={cardStyle}>
        <h2 style={{ textAlign: "center", color: "#203a43", marginBottom: "20px" }}>
          {isRegister ? "Join ChainDocs" : "Trade Finance Platform"}
        </h2>

        <form onSubmit={handleSubmit}>
          {isRegister && (
            <>
              <input
                placeholder="Full Name"
                style={inputStyle}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                required
              />
              <input
                placeholder="Username"
                style={inputStyle}
                onChange={(e) =>
                  setFormData({ ...formData, username: e.target.value })
                }
                required
              />
              <input
                placeholder="Organization Name"
                style={inputStyle}
                onChange={(e) =>
                  setFormData({ ...formData, org_name: e.target.value })
                }
                required
              />
              <select
                style={inputStyle}
                value={formData.role}
                onChange={(e) =>
                  setFormData({ ...formData, role: e.target.value })
                }
              >
                <option value="corporate">Corporate</option>
                <option value="bank">Bank</option>
              </select>
            </>
          )}

          <input
            type="email"
            placeholder="Email"
            style={inputStyle}
            onChange={(e) =>
              setFormData({ ...formData, email: e.target.value })
            }
            required
          />

          <input
            type="password"
            placeholder="Password"
            style={inputStyle}
            onChange={(e) =>
              setFormData({ ...formData, password: e.target.value })
            }
            required
          />

          <button type="submit" style={buttonStyle}>
            {isRegister ? "Create Account" : "Login"}
          </button>
        </form>

        <p style={{ marginTop: "15px", textAlign: "center" }}>
          {isRegister ? "Already have an account?" : "New user?"}
          <span
            onClick={() => setIsRegister(!isRegister)}
            style={{ marginLeft: "5px", cursor: "pointer", fontWeight: "bold" }}
          >
            {isRegister ? "Login here" : "Create an account"}
          </span>
        </p>

        {error && <div style={errorBox}>{error}</div>}
      </div>
    </div>
  );
}

/* styles unchanged */
const containerStyle = {
  height: "100vh",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  background: "linear-gradient(135deg, #0f2027, #203a43, #2c5364)",
};

const cardStyle = {
  background: "#fff",
  padding: "30px",
  width: "350px",
  borderRadius: "10px",
  boxShadow: "0 4px 15px rgba(0,0,0,0.2)",
};

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "15px",
  borderRadius: "5px",
  border: "1px solid #ccc",
  boxSizing: "border-box",
};

const buttonStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "20px",
  background: "#203a43",
  color: "#fff",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
  fontSize: "16px",
};

const errorBox = {
  color: "#b91c1c",
  background: "#fee2e2",
  padding: "10px",
  borderRadius: "5px",
  textAlign: "center",
  fontSize: "12px",
  marginTop: "15px",
  border: "1px solid #fca5a5",
};


