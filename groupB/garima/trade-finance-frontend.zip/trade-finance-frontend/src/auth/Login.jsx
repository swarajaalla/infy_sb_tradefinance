import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";


export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const navigate = useNavigate();

  const login = async () => {
    try {
      const res = await axios.post("http://127.0.0.1:8000/auth/login", {
        email,
        password,
      });

      localStorage.setItem("token", res.data.access_token);

      // ✅ REDIRECT TO DASHBOARD
      navigate("/app");
    } catch (err) {
      setError("Invalid credentials");
    }
  };

  return (
    <div style={containerStyle}>
      <div style={cardStyle}>
        <h2 style={{ textAlign: "center" }}>Trade Finance Platform</h2>

        <input
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          style={inputStyle}
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={inputStyle}
        />

        <button onClick={login} style={buttonStyle}>
          Login
        </button>

        {error && <p style={{ color: "red" }}>{error}</p>}
      </div>
    </div>
  );
}

/* ---------- STYLES ---------- */

const containerStyle = {
  height: "100vh",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  background: "linear-gradient(135deg, #0f2027, #203a43, #2c5364)",
};

const cardStyle = {
  background: "#fff",
  padding: "30px",
  width: "350px",
  borderRadius: "10px",
};

const inputStyle = {
  width: "100%",
  padding: "10px",
  marginTop: "15px",
};

const buttonStyle = {
  width: "100%",
  padding: "10px",
  marginTop: "20px",
  background: "#203a43",
  color: "#fff",
  border: "none",
  cursor: "pointer",
};

