import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";

export default function Register() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    full_name: "",
    role: "corporate" // Default role as per your requirement
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault(); // Form reload hone se rokne ke liye
    setLoading(true);
    setError("");

    try {
      // Backend registration endpoint
      await axios.post("http://127.0.0.1:8000/auth/register", formData);
      
      alert("✅ Registration Successful! Please Login.");
      navigate("/login");
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.detail || "Registration Failed. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={containerStyle}>
      <div style={cardStyle}>
        <h2 style={{ textAlign: "center", color: "#203a43" }}>Join ChainDocs</h2>
        <p style={{ textAlign: "center", fontSize: "14px", color: "#666" }}>
          Secure Trade Finance Ledger
        </p>

        <form onSubmit={handleRegister}>
          <input 
            required
            placeholder="Full Name" 
            value={formData.full_name}
            onChange={(e) => setFormData({...formData, full_name: e.target.value})} 
            style={inputStyle} 
          />
          
          <input 
            required
            type="email"
            placeholder="Email Address" 
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})} 
            style={inputStyle} 
          />
          
          <input 
            required
            type="password"
            placeholder="Password" 
            value={formData.password}
            onChange={(e) => setFormData({...formData, password: e.target.value})} 
            style={inputStyle} 
          />
          
          <label style={{ display: "block", marginTop: "15px", fontSize: "12px", color: "#555" }}>
            Select Your Role:
          </label>
          <select 
            value={formData.role} 
            onChange={(e) => setFormData({...formData, role: e.target.value})} 
            style={inputStyle}
          >
            <option value="corporate">Corporate (Exporter/Importer)</option>
            <option value="bank">Bank Official</option>
          </select>

          <button 
            type="submit" 
            disabled={loading} 
            style={loading ? {...buttonStyle, opacity: 0.7} : buttonStyle}
          >
            {loading ? "Creating Account..." : "Register"}
          </button>
        </form>

        <p style={{ textAlign: "center", marginTop: "20px", fontSize: "14px" }}>
          Already have an account? <Link to="/login" style={{ color: "#2c5364", fontWeight: "bold" }}>Login Here</Link>
        </p>

        {error && <p style={{ color: "red", textAlign: "center", marginTop: "10px", fontSize: "13px" }}>{error}</p>}
      </div>
    </div>
  );
}

/* ---------- STYLES ---------- */
const containerStyle = {
  height: "100vh",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  background: "linear-gradient(135deg, #0f2027, #203a43, #2c5364)",
};

const cardStyle = {
  background: "#fff",
  padding: "40px",
  borderRadius: "12px",
  width: "380px",
  boxShadow: "0 10px 25px rgba(0,0,0,0.3)",
};

const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "12px",
  borderRadius: "6px",
  border: "1px solid #ddd",
  boxSizing: "border-box", // Taaki padding width se bahar na jaye
};

const buttonStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "25px",
  background: "#203a43",
  color: "#fff",
  border: "none",
  borderRadius: "6px",
  cursor: "pointer",
  fontWeight: "bold",
  fontSize: "16px",
};