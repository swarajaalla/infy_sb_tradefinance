import enum
from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime, JSON, Enum, Numeric
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.database import Base

# 1. USER ROLE ENUM
class UserRole(str, enum.Enum):
    admin = "admin"
    bank = "bank"
    corporate = "corporate"
    auditor = "auditor"

# 2. USER MODEL (v4)
class User(Base):
    __tablename__ = "users_v4"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    password = Column(String(255), nullable=False)
    role = Column(Enum(UserRole, name="user_role_v4"), nullable=False, default=UserRole.corporate)
    org_name = Column(String(150), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    applied_trades = relationship("TradeTransaction", foreign_keys="TradeTransaction.buyer_id", back_populates="buyer")
    actions_performed = relationship("LedgerEntry", back_populates="actor")

# 3. TRADE TRANSACTION MODEL (v4)
class TradeTransaction(Base):
    __tablename__ = "trade_transactions_v4"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    description = Column(String, nullable=True)
    amount = Column(Numeric(15, 2), nullable=False) 
    currency = Column(String(3), default="USD") 
    status = Column(String(30), default="pending") 

    # ForeignKeys updated to 'users_v4.id' (Mismatch fix)
    buyer_id = Column(Integer, ForeignKey("users_v4.id"), nullable=False)
    bank_id = Column(Integer, ForeignKey("users_v4.id"), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    buyer = relationship("User", foreign_keys=[buyer_id], back_populates="applied_trades")
    documents = relationship("Document", back_populates="trade", cascade="all, delete-orphan")

# 4. DOCUMENT MODEL (v4)
class Document(Base):
    __tablename__ = "documents_v4"

    id = Column(Integer, primary_key=True, index=True)
    # FIX: Yahan trade_transactions_v3 ko v4 kar diya hai
    trade_id = Column(Integer, ForeignKey("trade_transactions_v4.id"), nullable=False)
    
    doc_type = Column(String(50), nullable=False) 
    doc_number = Column(String(100), nullable=True)
    file_url = Column(String(255), nullable=False) 
    file_hash = Column(String(64), nullable=False) 
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    trade = relationship("TradeTransaction", back_populates="documents")

# 5. LEDGER ENTRY MODEL (v4)
class LedgerEntry(Base):
    __tablename__ = "ledger_entries_v4"

    id = Column(Integer, primary_key=True, index=True)
    entity_type = Column(String(50), nullable=False) 
    entity_id = Column(Integer, nullable=False)
    action = Column(String(50), nullable=False)      
    
    actor_id = Column(Integer, ForeignKey("users_v4.id"), nullable=True)
    
    previous_hash = Column(String(64), nullable=True)
    hash = Column(String(64), nullable=False)         
    
    metadata_json = Column(JSON, nullable=True) 
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    actor = relationship("User", back_populates="actions_performed")




