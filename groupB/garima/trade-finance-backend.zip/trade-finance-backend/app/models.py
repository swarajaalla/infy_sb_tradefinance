from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Numeric
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from datetime import datetime, timezone
from .database import Base
from sqlalchemy import JSON


# ===================== USERS =====================
class Users(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    email = Column(String, unique=True, index=True)
    password = Column(String)
    role = Column(String)
    org_name = Column(String)


# ===================== TRADES =====================
class Trades(Base):
    __tablename__ = "trades"

    id = Column(Integer, primary_key=True, index=True)
    trade_ref = Column(String, unique=True, nullable=False)
    title = Column(String, nullable=False)
    description = Column(String)
    amount = Column(Numeric, nullable=False)
    currency = Column(String(10), default="INR")
    status = Column(String(30), nullable=False)

    applicant_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=False)

    created_at = Column(DateTime, server_default=func.now())


# ===================== TRADE STATUS LOG =====================
class TradeStatusLogs(Base):
    __tablename__ = "trade_status_logs"

    id = Column(Integer, primary_key=True, index=True)
    trade_id = Column(Integer, ForeignKey("trades.id", ondelete="CASCADE"))

    old_status = Column(String(30))
    new_status = Column(String(30), nullable=False)

    changed_by = Column(Integer, ForeignKey("users.id"))
    changed_at = Column(DateTime, server_default=func.now())


# ===================== DOCUMENTS =====================
class TradeDocuments(Base):
    __tablename__ = "trade_documents"

    id = Column(Integer, primary_key=True, index=True)
    trade_id = Column(Integer, ForeignKey("trades.id"), nullable=False)

    file_name = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    file_hash = Column(String, nullable=False)

    uploaded_by = Column(Integer, ForeignKey("users.id"), nullable=False)
    uploaded_at = Column(DateTime, default=datetime.utcnow)

    trade = relationship("Trades")


# ===================== LEDGER =====================
class LedgerEntry(Base):
    __tablename__ = "ledger_entries"

    id = Column(Integer, primary_key=True, index=True)

    entity_type = Column(String, nullable=False)   # TRADE / DOCUMENT
    entity_id = Column(Integer, nullable=False)

    action = Column(String, nullable=False)        # UPLOAD / VERIFY
    hash = Column(String, nullable=False)
    previous_hash = Column(String, nullable=True)

    extra_data = Column(JSON, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)








