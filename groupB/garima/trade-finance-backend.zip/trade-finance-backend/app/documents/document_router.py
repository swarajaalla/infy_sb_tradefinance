from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from fastapi.security import HTTPBearer
from datetime import datetime
import os
import shutil

from ..database import SessionLocal
from ..models import TradeDocuments, Trades
from ..auth.jwt_handler import verify_access_token
from app.ledger.ledger_service import create_ledger_entry
from app.ledger.hash_utils import hash_file

router = APIRouter(prefix="/documents", tags=["Documents"])

security = HTTPBearer()

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/upload/{trade_id}")
def upload_document(
    trade_id: int,
    file: UploadFile = File(...),
    token=Depends(security),
    db: Session = Depends(get_db)
):
    payload = verify_access_token(token.credentials)

    trade = db.query(Trades).filter(Trades.id == trade_id).first()
    if not trade:
        raise HTTPException(status_code=404, detail="Trade not found")

    # ✅ Read file safely
    file_bytes = file.file.read()
    file.file.seek(0)

    file_hash = hash_file(file_bytes)

    timestamp = int(datetime.utcnow().timestamp())
    safe_filename = f"{trade_id}_{timestamp}_{file.filename}"
    file_path = os.path.join(UPLOAD_DIR, safe_filename)

    with open(file_path, "wb") as f:
        f.write(file_bytes)

    document = TradeDocuments(
        trade_id=trade_id,
        file_name=file.filename,
        file_path=file_path,
        file_hash=file_hash,
        uploaded_by=payload["user_id"],
        uploaded_at=datetime.utcnow()
    )

    db.add(document)
    db.commit()
    db.refresh(document)

    # 🔐 Ledger entry (CHAIN SAFE)
    create_ledger_entry(
        db=db,
        entity_type="DOCUMENT",
        entity_id=document.id,
        action="UPLOAD",
        extra_data={"file_hash": file_hash}
    )

    return {
        "message": "Document uploaded successfully",
        "document_id": document.id,
        "file_hash": file_hash
    }

