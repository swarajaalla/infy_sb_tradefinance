# from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
# from sqlalchemy.orm import Session
# import os

# from app.database import SessionLocal
# from app.auth.jwt_handler import verify_access_token
# from fastapi.security import HTTPBearer

# from app.models import Document, Trade
# from app.utils.hash_utils import hash_file
# from app.ledger.ledger_service import create_ledger_entry   # ✅ IMPORT
# from app.trades.constants import TradeStatus                # ✅ IMPORT

# router = APIRouter(prefix="/documents", tags=["Documents"])
# security = HTTPBearer()

# UPLOAD_DIR = "uploads"
# os.makedirs(UPLOAD_DIR, exist_ok=True)


# # ---------------- DB DEPENDENCY ----------------
# def get_db():
#     db = SessionLocal()
#     try:
#         yield db
#     finally:
#         db.close()


# # ---------------- AUTH DEPENDENCY ----------------
# def get_current_user(token=Depends(security)):
#     return verify_access_token(token.credentials)


# # ---------------- UPLOAD DOCUMENT ----------------
# @router.post("/upload/{trade_id}")
# def upload_document(
#     trade_id: int,
#     file: UploadFile = File(...),
#     db: Session = Depends(get_db),
#     current_user=Depends(get_current_user)
# ):
#     trade = db.query(Trade).filter(Trade.id == trade_id).first()
#     if not trade:
#         raise HTTPException(status_code=404, detail="Trade not found")

#     file_path = os.path.join(UPLOAD_DIR, file.filename)

#     with open(file_path, "wb") as f:
#         f.write(file.file.read())

#     file_hash = hash_file(file_path)

#     document = Document(
#         trade_id=trade.id,
#         file_path=file_path,
#         file_hash=file_hash
#     )

#     db.add(document)

#     # ✅ UPDATE TRADE STATUS
#     trade.status = TradeStatus.DOCUMENTS_UPLOADED

#     db.commit()
#     db.refresh(document)

#     # ✅ LEDGER ENTRY (INSIDE FUNCTION — CORRECT)
#     create_ledger_entry(
#         db=db,
#         entity_type="DOCUMENT",
#         entity_id=document.id,
#         action="UPLOADED",
#         extra_data={
#             "trade_id": trade.id,
#             "uploaded_by": current_user["email"]
#         }
#     )

#     return {
#         "message": "Document uploaded successfully",
#         "document_id": document.id,
#         "hash": file_hash
#     }


from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
import os

from app.database import SessionLocal
from app.auth.jwt_handler import verify_access_token
from fastapi.security import HTTPBearer

from app.models import Document, TradeTransaction
from app.utils.hash_utils import hash_file
from app.ledger.ledger_service import create_ledger_entry
from app.trades.constants import TradeStatus

router = APIRouter(prefix="/documents", tags=["Documents"])
security = HTTPBearer()

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)


# ---------------- DB DEPENDENCY ----------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ---------------- AUTH DEPENDENCY ----------------
def get_current_user(token=Depends(security)):
    return verify_access_token(token.credentials)


# ---------------- UPLOAD DOCUMENT ----------------
@router.post("/upload/{trade_id}")
def upload_document(
    trade_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    trade = db.query(trade).filter(trade.id == trade_id).first()
    if not trade:
        raise HTTPException(status_code=404, detail="Trade not found")

    if trade.status in [TradeStatus.SUBMITTED, TradeStatus.VERIFIED,
                        TradeStatus.APPROVED, TradeStatus.REJECTED]:
        raise HTTPException(
            status_code=400,
            detail="Cannot upload documents after submission"
        )

    file_path = os.path.join(UPLOAD_DIR, file.filename)

    with open(file_path, "wb") as f:
        f.write(file.file.read())

    file_hash = hash_file(file_path)

    document = Document(
        trade_id=trade.id,
        file_path=file_path,
        file_hash=file_hash
    )

    db.add(document)

    # Update trade status
    trade.status = TradeStatus.DOCUMENTS_UPLOADED

    db.commit()
    db.refresh(document)

    # Ledger entry
    create_ledger_entry(
        db=db,
        entity_type="DOCUMENT",
        entity_id=document.id,
        action="UPLOADED",
        extra_data={
            "trade_id": trade.id,
            "uploaded_by": current_user["email"]
        }
    )

    return {
        "message": "Document uploaded successfully",
        "document_id": document.id,
        "hash": file_hash
    }

