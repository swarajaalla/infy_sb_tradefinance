from sqlalchemy.orm import Session
from datetime import datetime
import os
from app.models import Document, TradeTransaction  # Sahi models use karein
from app.ledger.ledger_service import create_ledger_entry
from app.ledger.hash_utils import hash_file

UPLOAD_DIR = "app/uploads"

def upload_document_service(db: Session, trade_id: int, file, user_id: int):
    # 1. TradeTransaction check karein (_v3 table automatically use hogi)
    trade = db.query(TradeTransaction).filter(TradeTransaction.id == trade_id).first()
    if not trade:
        raise ValueError("Trade not found")

    # 2. SHA-256 Hash generate karein (As per PDF)
    file_bytes = file.file.read()
    file_hash = hash_file(file_bytes)

    os.makedirs(UPLOAD_DIR, exist_ok=True)
    filename = f"{trade_id}_{int(datetime.utcnow().timestamp())}_{file.filename}"
    file_path = os.path.join(UPLOAD_DIR, filename)

    with open(file_path, "wb") as f:
        f.write(file_bytes)

    # 3. Document table mein save karein
    document = Document(
        trade_id=trade_id,
        doc_type=file.content_type, # Model ke hisaab se doc_type
        file_url=file_path,         # Model ke hisaab se file_url
        file_hash=file_hash,
    )

    db.add(document)
    
    # 🔄 Trade status update karein
    trade.status = "documents_uploaded"
    db.commit()
    db.refresh(document)

    # 4. Ledger entry (actor_id ke saath)
    create_ledger_entry(
        db=db,
        entity_type="DOCUMENT",
        entity_id=document.id,
        action="DOCUMENT_UPLOADED",
        actor_id=user_id # <--- actor_id pass karna zaroori hai
    )

    return document
