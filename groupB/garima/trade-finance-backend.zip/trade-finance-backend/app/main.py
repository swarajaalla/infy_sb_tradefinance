from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import Base, engine
import app.models  

# Database tables create karein
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="ChainDocs Trade Finance API",
    description="Blockchain-based Trade Document Verification System",
    version="3.0.0"
)

# --- ROUTERS IMPORT ---
from app.auth.auth_router import router as auth_router
from app.trades.trade_router import router as trade_router
from app.documents.document_router import router as document_router
from app.ledger.ledger_router import router as ledger_router
from app.integrity.integrity_router import router as integrity_router

# --- CORS SETUP ---
# Isse frontend (React/Vite) ko backend se baat karne ki permission milti hai
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- ROUTER INCLUSION (FIXED PREFIXES) ---
# Note: Agar router file ke andar pehle se path likha hai, toh yahan prefix dhyan se lagayein.
# Humne yahan standard prefixes diye hain taaki frontend URLs clean rahein.

app.include_router(auth_router, prefix="/auth", tags=["Authentication"])
app.include_router(trade_router, prefix="/trades", tags=["Trades"])
app.include_router(document_router, prefix="/documents", tags=["Documents"])
app.include_router(ledger_router, prefix="/ledger", tags=["Ledger"])
app.include_router(integrity_router, prefix="/integrity", tags=["Integrity"])

@app.get("/")
def root():
    return {
        "status": "ChainDocs Backend Online",
        "docs_url": "/docs",
        "version": "3.0.0"
    }







