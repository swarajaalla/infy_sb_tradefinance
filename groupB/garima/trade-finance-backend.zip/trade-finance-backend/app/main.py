from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .auth.auth_router import router as auth_router
from .trades.trade_router import router as trade_router
from .documents.document_router import router as document_router
from .ledger.ledger_router import router as ledger_router
from .database import Base, engine
from . import models

Base.metadata.create_all(bind=engine)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ❗ PREFIX SIRF ROUTER ME HOGA
app.include_router(auth_router)
app.include_router(trade_router)
app.include_router(document_router)
app.include_router(ledger_router)

@app.get("/")
def root():
    return {"message": "Backend is running"}





