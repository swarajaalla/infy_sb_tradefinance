from pydantic_settings import BaseSettings

class Settings:
    DATABASE_URL = "postgresql://postgres:<PASSWORD>@localhost:5432/trade_finance"
    SECRET_KEY = "supersecret"
    ALGORITHM = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES = 60

settings = Settings()




