from apscheduler.schedulers.background import BackgroundScheduler
from app.ledger.integrity_job import run_ledger_integrity_check


def start_scheduler():
    scheduler = BackgroundScheduler()

    # 🔁 Run every 2 minutes (change if needed)
    scheduler.add_job(
        run_ledger_integrity_check,
        trigger="interval",
        minutes=2,
        id="ledger_integrity_job",
        replace_existing=True
    )

    scheduler.start()
