from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.ledger.ledger_service import verify_full_ledger
import logging

logger = logging.getLogger(__name__)


def run_ledger_integrity_check():
    """
    Background job:
    - Verifies full ledger chain
    - Logs alert if tampering detected
    """

    db: Session = SessionLocal()
    try:
        is_valid, broken_id = verify_full_ledger(db)

        if is_valid:
            logger.info("Ledger integrity check PASSED")
        else:
            logger.error(
                f"🚨 LEDGER TAMPER DETECTED at entry ID {broken_id}"
            )

    except Exception as e:
        logger.exception("Ledger integrity job failed")

    finally:
        db.close()
