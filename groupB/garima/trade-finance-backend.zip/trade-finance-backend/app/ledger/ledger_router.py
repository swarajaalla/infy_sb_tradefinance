from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from fastapi.security import HTTPBearer

from app.database import SessionLocal
from app.auth.jwt_handler import verify_access_token
from app.ledger.ledger_service import (
    get_integrity_summary,
    get_integrity_alerts
)

router = APIRouter(prefix="/ledger/integrity", tags=["Ledger Integrity"])
security = HTTPBearer()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/summary")
def integrity_summary(
    token=Depends(security),
    db: Session = Depends(get_db)
):
    verify_access_token(token.credentials)
    return get_integrity_summary(db)


@router.get("/alerts")
def integrity_alerts(
    token=Depends(security),
    db: Session = Depends(get_db)
):
    verify_access_token(token.credentials)
    return get_integrity_alerts(db)

