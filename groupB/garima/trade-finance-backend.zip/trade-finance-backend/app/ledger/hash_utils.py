import hashlib
import json

def generate_hash(data: dict) -> str:
    """
    Generate SHA-256 hash for ledger chaining
    """
    serialized = json.dumps(data, sort_keys=True).encode()
    return hashlib.sha256(serialized).hexdigest()


def hash_file(file_bytes: bytes) -> str:
    """
    Generate SHA-256 hash of uploaded document file
    """
    return hashlib.sha256(file_bytes).hexdigest()
