import hashlib
import json

def generate_hash(data: dict) -> str:
    """
    Generate SHA-256 hash for ledger chaining
    """
    serialized = json.dumps(data, sort_keys=True).encode()
    return hashlib.sha256(serialized).hexdigest()


def hash_file(file_bytes: bytes) -> str:
    """
    Generate SHA-256 hash of uploaded document file
    """
    return hashlib.sha256(file_bytes).hexdigest()

def verify_hash(file_path: str, expected_hash: str) -> bool:
    """
    Recalculate hash of stored file and compare with expected hash
    """
    with open(file_path, "rb") as f:
        file_bytes = f.read()

    calculated_hash = hashlib.sha256(file_bytes).hexdigest()
    return calculated_hash == expected_hash
