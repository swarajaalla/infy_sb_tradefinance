from sqlalchemy.orm import Session
from app.models import LedgerEntry
from app.ledger.hash_utils import generate_hash


# =========================================================
# CREATE LEDGER ENTRY (WRITE SIDE)
# =========================================================
def create_ledger_entry(
    db: Session,
    entity_type: str,
    entity_id: int,
    action: str,
    extra_data: dict | None = None
):
    """
    Creates a new ledger entry with hash chaining
    """

    # 1️⃣ Get last ledger entry
    last_entry = (
        db.query(LedgerEntry)
        .order_by(LedgerEntry.id.desc())
        .first()
    )

    # 2️⃣ Determine previous hash
    previous_hash = last_entry.hash if last_entry else "GENESIS"

    # 3️⃣ Prepare deterministic hash payload
    data_to_hash = {
        "entity_type": entity_type,
        "entity_id": entity_id,
        "action": action,
        "previous_hash": previous_hash,
        "extra_data": extra_data,
    }

    # 4️⃣ Generate current hash
    current_hash = generate_hash(data_to_hash)

    # 5️⃣ Create ledger record
    ledger_entry = LedgerEntry(
        entity_type=entity_type,
        entity_id=entity_id,
        action=action,
        previous_hash=previous_hash,
        hash=current_hash,
        extra_data=extra_data,
    )

    # 6️⃣ Persist
    db.add(ledger_entry)
    db.commit()
    db.refresh(ledger_entry)

    return ledger_entry


# =========================================================
# VERIFY FULL LEDGER CHAIN (READ / AUDIT SIDE)
# =========================================================
def verify_full_ledger(db: Session):
    """
    Verifies entire ledger chain integrity.
    Returns: (is_valid: bool, broken_ledger_id: int | None)
    """

    entries = (
        db.query(LedgerEntry)
        .order_by(LedgerEntry.id.asc())
        .all()
    )

    previous_hash = "GENESIS"

    for entry in entries:
        data_to_hash = {
            "entity_type": entry.entity_type,
            "entity_id": entry.entity_id,
            "action": entry.action,
            "previous_hash": previous_hash,
            "extra_data": entry.extra_data,
        }

        expected_hash = generate_hash(data_to_hash)

        if entry.hash != expected_hash:
            return False, entry.id

        previous_hash = entry.hash

    return True, None


# =========================================================
# DASHBOARD INTEGRITY SUMMARY
# =========================================================
def get_integrity_summary(db: Session):
    """
    Returns summary metrics for dashboard cards
    """

    total = db.query(LedgerEntry).count()

    is_valid, broken_id = verify_full_ledger(db)

    if is_valid:
        passed = total
        failed = 0
    else:
        passed = broken_id - 1
        failed = total - passed

    pass_rate = (passed / total * 100) if total > 0 else 0

    return {
        "total": total,
        "passed": passed,
        "failed": failed,
        "pending": 0,
        "pass_rate": round(pass_rate, 2),
    }


# =========================================================
# INTEGRITY ALERTS (FOR UI)
# =========================================================
def get_integrity_alerts(db: Session):
    """
    Returns tampering alerts for dashboard
    """

    is_valid, broken_id = verify_full_ledger(db)

    if is_valid:
        return []

    broken_entry = (
        db.query(LedgerEntry)
        .filter(LedgerEntry.id == broken_id)
        .first()
    )

    return [
        {
            "severity": "HIGH",
            "type": "LEDGER_TAMPERED",
            "reference": f"{broken_entry.entity_type}-{broken_entry.entity_id}",
            "message": f"Ledger tampered at entry {broken_id}",
            "created_at": broken_entry.created_at,
        }
    ]



