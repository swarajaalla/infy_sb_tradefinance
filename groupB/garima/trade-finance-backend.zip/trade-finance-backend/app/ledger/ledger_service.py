from sqlalchemy.orm import Session
from app.models import LedgerEntry
from app.ledger.hash_utils import generate_hash

def create_ledger_entry(db: Session, entity_type: str, entity_id: int, action: str, actor_id: int, extra_data: dict = None): 
    """
    Creates a new ledger entry with hash chaining
    """
    # Get last ledger entry
    last_entry = (
        db.query(LedgerEntry)
        .order_by(LedgerEntry.id.desc())
        .first()
    )

    previous_hash = last_entry.hash if last_entry else "GENESIS"

    # actor_id aur metadata_json ko hashing data mein include karein
    data_to_hash = {
        "entity_type": entity_type,
        "entity_id": entity_id,
        "action": action,
        "actor_id": actor_id,
        "previous_hash": previous_hash,
        "metadata_json": extra_data,
    }

    current_hash = generate_hash(data_to_hash)

    ledger_entry = LedgerEntry(
        entity_type=entity_type,
        entity_id=entity_id,
        action=action,
        actor_id=actor_id,
        previous_hash=previous_hash,
        hash=current_hash,
        metadata_json=extra_data, # Metadata column name matched
    )

    db.add(ledger_entry)
    db.commit()
    db.refresh(ledger_entry)

    return ledger_entry


def verify_full_ledger(db: Session):
    """
    Verifies entire ledger chain
    Returns (is_valid, broken_ledger_id)
    """

    entries = (
        db.query(LedgerEntry)
        .order_by(LedgerEntry.id.asc())
        .all()
    )

    previous_hash = "GENESIS"

    for entry in entries:
        # Fixed: Changed extra_data to metadata_json
        data_to_hash = {
            "entity_type": entry.entity_type,
            "entity_id": entry.entity_id,
            "action": entry.action,
            "actor_id": entry.actor_id, # Hash verification mein actor_id bhi zaroori hai
            "previous_hash": previous_hash,
            "metadata_json": entry.metadata_json,
        }

        expected_hash = generate_hash(data_to_hash)

        if entry.hash != expected_hash:
            return False, entry.id

        previous_hash = entry.hash

    return True, None


def get_integrity_summary(db: Session):
    """
    Summary used for dashboard cards
    """
    total = db.query(LedgerEntry).count()
    if total == 0:
        return {"total": 0, "passed": 0, "failed": 0, "pending": 0, "pass_rate": 0}

    valid, broken_id = verify_full_ledger(db)

    passed = total if valid else broken_id - 1
    failed = 0 if valid else total - passed
    pass_rate = (passed / total * 100)

    return {
        "total": total,
        "passed": passed,
        "failed": failed,
        "pending": 0,
        "pass_rate": round(pass_rate, 2)
    }


def get_integrity_alerts(db: Session):
    """
    Returns ledger tampering alerts
    """
    valid, broken_id = verify_full_ledger(db)

    if valid:
        return []

    broken_entry = (
        db.query(LedgerEntry)
        .filter(LedgerEntry.id == broken_id)
        .first()
    )

    return [
        {
            "severity": "HIGH",
            "type": "LEDGER_TAMPERED",
            "reference": f"{broken_entry.entity_type}-{broken_entry.entity_id}",
            "message": f"Ledger tampered at entry {broken_id}",
            "created_at": broken_entry.created_at,
        }
    ]


