from pydantic import BaseModel, EmailStr
from enum import Enum
from typing import Optional
from datetime import datetime

# --- AUTH SCHEMAS ---
class UserRole(str, Enum):
    ADMIN = "admin"
    BANK = "bank"
    CORPORATE = "corporate"
    AUDITOR = "auditor"

class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: UserRole
    org_name: Optional[str] = None

# YE MISSING THA - AB THEEK HAI
class UserLogin(BaseModel):
    email: EmailStr
    password: str

class LoginResponse(BaseModel):
    access_token: str
    token_type: str
    role: str
    name: str

class UserResponse(BaseModel):
    id: int
    name: str
    email: EmailStr
    role: UserRole
    org_name: Optional[str]
    class Config:
        from_attributes = True

# --- TRADE SCHEMAS ---
class TradeCreate(BaseModel):
    title: str
    description: Optional[str] = None
    amount: float

class TradeResponse(BaseModel):
    id: int
    title: str
    description: Optional[str] = None
    amount: float
    currency: str = "USD"
    status: str
    buyer_id: int 
    created_at: datetime
    # YE LINE ZAROORI HAI: Taaki frontend ko doc status mil sake
    has_documents: bool = False 
    
    class Config:
        from_attributes = True
