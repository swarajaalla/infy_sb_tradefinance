from pydantic import BaseModel, EmailStr
from enum import Enum
from typing import Optional
from datetime import datetime

class UserRole(str, Enum):
    bank = "bank"
    corporate = "corporate"
    auditor = "auditor"
    admin = "admin"

class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: UserRole
    org_name: str

class UserLogin(BaseModel):
    email: str
    password: str


class UserResponse(BaseModel):
    id: int
    name: str
    email: EmailStr
    role: UserRole
    org_name: str

    class Config:
        from_attributes = True

class TradeCreate(BaseModel):
    title: str
    description: Optional[str] = None
    amount: int


class TradeResponse(BaseModel):
    id: int
    title: str
    description: Optional[str]
    amount: int
    status: str
    created_by: int
    created_at: datetime

    class Config:
        from_attributes = True   
