from app.models import Document

from app.utils.hash_utils import hash_file_bytes

def run_integrity_check(db):
    results = []

    documents = db.query(Document).all()

    for doc in documents:
        try:
            with open(doc.file_path, "rb") as f:
                current_hash = hash_file_bytes(f.read())

            status = "OK" if current_hash == doc.file_hash else "TAMPERED"

            results.append({
                "document_id": doc.id,
                "filename": doc.filename,
                "status": status
            })

        except Exception:
            results.append({
                "document_id": doc.id,
                "filename": doc.filename,
                "status": "ERROR"
            })

    return results

