from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.auth.role_checker import require_roles

# ✅ CORRECT: import from app.models
from app.models import Trade, Document, LedgerEntry, User

router = APIRouter(prefix="/admin", tags=["Admin"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/dashboard")
def admin_dashboard(
    db: Session = Depends(get_db),
    _=Depends(require_roles(["ADMIN"]))
):
    return {
        "total_trades": db.query(Trade).count(),
        "created": db.query(Trade).filter(Trade.status == "CREATED").count(),
        "verified": db.query(Trade).filter(Trade.status == "VERIFIED").count(),
        "approved": db.query(Trade).filter(Trade.status == "APPROVED").count(),
        "settled": db.query(Trade).filter(Trade.status == "SETTLED").count(),
        "documents": db.query(Document).count(),
        "ledger_entries": db.query(LedgerEntry).count(),
        "users": db.query(User).count(),
    }



