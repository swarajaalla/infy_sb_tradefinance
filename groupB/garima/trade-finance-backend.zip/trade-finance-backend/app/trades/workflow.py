WORKFLOW_RULES = {
    "CREATED": {
        "SUBMITTED": ["BANK"]
    },
    "SUBMITTED": {
        "VERIFIED": ["VERIFIER"],
        "REJECTED": ["VERIFIER", "ADMIN"]
    },
    "VERIFIED": {
        "APPROVED": ["APPROVER"],
        "REJECTED": ["APPROVER", "ADMIN"]
    }
}
