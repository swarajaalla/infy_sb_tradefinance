from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.models import Trade, TradeDocument
from app.trades.constants import TradeStatus
from app.ledger.constants import LedgerAction
from app.ledger.ledger_service import create_ledger_entry
from app.ledger.hash_utils import verify_hash


def verify_trade(db: Session, trade_id: int, user_id: int):
    trade = db.query(Trade).filter(Trade.id == trade_id).first()

    if trade.status != TradeStatus.DOCUMENTS_UPLOADED:
        raise HTTPException(400, "Documents not uploaded")

    documents = db.query(TradeDocument).filter(
        TradeDocument.trade_id == trade_id
    ).all()

    if not documents:
        raise HTTPException(400, "No documents found")

    for doc in documents:
        if not verify_hash(doc.file_path, doc.file_hash):
            raise HTTPException(400, "Document hash mismatch")

    trade.status = TradeStatus.VERIFIED
    db.commit()

    create_ledger_entry(
        db=db,
        entity_type="TRADE",
        entity_id=trade.id,
        action=LedgerAction.TRADE_VERIFY,
        extra_data={"verified_by": user_id}
    )

    return trade


def approve_trade(db: Session, trade_id: int, user):
    if user.role not in ["admin", "bank"]:
        raise HTTPException(403, "Not authorized")

    trade = db.query(Trade).filter(Trade.id == trade_id).first()

    if trade.status != TradeStatus.VERIFIED:
        raise HTTPException(400, "Trade not verified")

    trade.status = TradeStatus.APPROVED
    db.commit()

    create_ledger_entry(
        db=db,
        entity_type="TRADE",
        entity_id=trade.id,
        action=LedgerAction.TRADE_APPROVE,
        extra_data={"approved_by": user.id}
    )

    return trade


def settle_trade(db: Session, trade_id: int, user):
    trade = db.query(Trade).filter(Trade.id == trade_id).first()

    if trade.status != TradeStatus.APPROVED:
        raise HTTPException(400, "Trade not approved")

    trade.status = TradeStatus.SETTLED
    db.commit()

    create_ledger_entry(
        db=db,
        entity_type="TRADE",
        entity_id=trade.id,
        action=LedgerAction.TRADE_SETTLE,
        extra_data={"settled_by": user.id}
    )

    return trade
