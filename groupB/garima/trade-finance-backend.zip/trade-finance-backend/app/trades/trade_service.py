from fastapi import HTTPException
from .constants import TradeStatus


def validate_status_transition(current_status: str, new_status: str):
    allowed_transitions = {
        TradeStatus.CREATED: [TradeStatus.SUBMITTED],
        TradeStatus.SUBMITTED: [TradeStatus.UNDER_REVIEW],
        TradeStatus.UNDER_REVIEW: [TradeStatus.APPROVED, TradeStatus.REJECTED],
        TradeStatus.APPROVED: [TradeStatus.FUNDED],
    }

    if current_status not in allowed_transitions:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid current status: {current_status}"
        )

    if new_status not in allowed_transitions[current_status]:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid status change: {current_status} → {new_status}"
        )
