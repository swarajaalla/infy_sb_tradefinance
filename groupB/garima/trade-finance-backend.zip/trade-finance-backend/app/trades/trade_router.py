from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models import TradeTransaction, Document
from app.schemas import TradeCreate, TradeResponse
from app.ledger.ledger_service import create_ledger_entry
from app.auth.jwt_handler import get_current_user

# YAHAN SE prefix="/trades" HATA DIYA HAI
router = APIRouter(tags=["Trades"])

@router.get("/", response_model=List[TradeResponse])
async def get_all_trades(db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    if current_user["role"] == "corporate":
        trades = db.query(TradeTransaction).filter(TradeTransaction.buyer_id == current_user["user_id"]).all()
    else:
        trades = db.query(TradeTransaction).all()
    
    for trade in trades:
        doc_exists = db.query(Document).filter(Document.trade_id == trade.id).first()
        trade.has_documents = True if doc_exists else False
        
    return trades

@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_trade(trade: TradeCreate, db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    new_trade = TradeTransaction(
        title=trade.title, 
        description=trade.description, 
        amount=trade.amount,
        buyer_id=current_user["user_id"], 
        status="pending"
    )
    db.add(new_trade)
    db.commit()
    db.refresh(new_trade)
    
    create_ledger_entry(db=db, entity_type="TRADE", entity_id=new_trade.id, action="ISSUED", actor_id=current_user["user_id"])
    return {"message": "Trade Created Successfully", "trade_id": new_trade.id}

@router.post("/{trade_id}/submit")
async def submit_trade(trade_id: int, db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    trade = db.query(TradeTransaction).filter(TradeTransaction.id == trade_id).first()
    if not trade: 
        raise HTTPException(status_code=404, detail="Trade not found")

    doc_count = db.query(Document).filter(Document.trade_id == trade_id).count()
    if doc_count == 0:
        raise HTTPException(status_code=400, detail="Please upload document first.")

    trade.status = "submitted"
    db.commit()
    create_ledger_entry(db=db, entity_type="TRADE", entity_id=trade.id, action="SUBMITTED", actor_id=current_user["user_id"])
    return {"message": "Trade Sent to Bank"}

# Approve aur Reject endpoints same rahenge...

@router.post("/{trade_id}/approve")
async def approve_trade(trade_id: int, db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "bank": 
        raise HTTPException(status_code=403, detail="Only banks can approve")
    
    trade = db.query(TradeTransaction).filter(TradeTransaction.id == trade_id).first()
    trade.status = "approved"
    db.commit()
    create_ledger_entry(db=db, entity_type="TRADE", entity_id=trade.id, action="APPROVED", actor_id=current_user["user_id"])
    return {"message": "Approved"}

@router.post("/{trade_id}/reject")
async def reject_trade(trade_id: int, db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    if current_user["role"] != "bank": 
        raise HTTPException(status_code=403, detail="Only banks can reject")
    
    trade = db.query(TradeTransaction).filter(TradeTransaction.id == trade_id).first()
    trade.status = "rejected"
    db.commit()
    create_ledger_entry(db=db, entity_type="TRADE", entity_id=trade.id, action="REJECTED", actor_id=current_user["user_id"])
    return {"message": "Rejected"}