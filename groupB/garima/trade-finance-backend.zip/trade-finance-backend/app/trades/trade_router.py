from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime

from app.database import SessionLocal
from app.models import Trades, TradeStatusLogs
from app.schemas import TradeCreate, TradeResponse
from app.auth.dependencies import get_current_user
from app.trades.trade_service import validate_status_transition
from app.trades.constants import TradeStatus
from app.ledger.ledger_service import create_ledger_entry

router = APIRouter(prefix="/trades", tags=["Trades"])


# -----------------------------
# DATABASE DEPENDENCY
# -----------------------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# =========================================================
# CREATE TRADE (CORPORATE)
# =========================================================
@router.post("/", response_model=TradeResponse)
def create_trade(
    trade: TradeCreate,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if current_user.role != "corporate":
        raise HTTPException(
            status_code=403,
            detail="Only corporate users can create trades"
        )

    trade_ref = f"TF-{datetime.utcnow().year}-{int(datetime.utcnow().timestamp())}"

    new_trade = Trades(
        trade_ref=trade_ref,
        title=trade.title,
        description=trade.description,
        amount=trade.amount,
        currency="INR",
        status=TradeStatus.CREATED,
        applicant_id=current_user.id,
        created_by=current_user.id
    )

    db.add(new_trade)
    db.commit()
    db.refresh(new_trade)

    # Status Log
    log = TradeStatusLogs(
        trade_id=new_trade.id,
        old_status=None,
        new_status=TradeStatus.CREATED,
        changed_by=current_user.id
    )
    db.add(log)
    db.commit()

    # Ledger Entry
    create_ledger_entry(
        db=db,
        entity_type="TRADE",
        entity_id=new_trade.id,
        action="CREATE",
        extra_data={"status": TradeStatus.CREATED}
    )

    return new_trade


# =========================================================
# SUBMIT TRADE (CORPORATE)
# =========================================================
@router.post("/{trade_id}/submit")
def submit_trade(
    trade_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    trade = db.query(Trades).filter(Trades.id == trade_id).first()
    if not trade:
        raise HTTPException(status_code=404, detail="Trade not found")

    if trade.created_by != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized")

    validate_status_transition(trade.status, TradeStatus.SUBMITTED)

    old_status = trade.status
    trade.status = TradeStatus.SUBMITTED
    db.commit()

    db.add(
        TradeStatusLogs(
            trade_id=trade.id,
            old_status=old_status,
            new_status=TradeStatus.SUBMITTED,
            changed_by=current_user.id
        )
    )
    db.commit()

    create_ledger_entry(
        db=db,
        entity_type="TRADE",
        entity_id=trade.id,
        action="SUBMIT",
        extra_data={"new_status": TradeStatus.SUBMITTED}
    )

    return {"message": "Trade submitted successfully"}


# =========================================================
# REVIEW TRADE (BANK)
# =========================================================
@router.post("/{trade_id}/review")
def review_trade(
    trade_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if current_user.role != "bank":
        raise HTTPException(403, "Only bank users can review trades")

    trade = db.query(Trades).filter(Trades.id == trade_id).first()
    if not trade:
        raise HTTPException(404, "Trade not found")

    validate_status_transition(trade.status, TradeStatus.UNDER_REVIEW)

    old_status = trade.status
    trade.status = TradeStatus.UNDER_REVIEW
    db.commit()

    db.add(
        TradeStatusLogs(
            trade_id=trade.id,
            old_status=old_status,
            new_status=TradeStatus.UNDER_REVIEW,
            changed_by=current_user.id
        )
    )
    db.commit()

    create_ledger_entry(
        db=db,
        entity_type="TRADE",
        entity_id=trade.id,
        action="REVIEW",
        extra_data={"new_status": TradeStatus.UNDER_REVIEW}
    )

    return {"message": "Trade moved to UNDER_REVIEW"}


# =========================================================
# APPROVE TRADE (BANK)
# =========================================================
@router.post("/{trade_id}/approve")
def approve_trade(
    trade_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if current_user.role != "bank":
        raise HTTPException(403, "Only bank users allowed")

    trade = db.query(Trades).filter(Trades.id == trade_id).first()
    if not trade:
        raise HTTPException(404, "Trade not found")

    validate_status_transition(trade.status, TradeStatus.APPROVED)

    old_status = trade.status
    trade.status = TradeStatus.APPROVED
    db.commit()

    db.add(
        TradeStatusLogs(
            trade_id=trade.id,
            old_status=old_status,
            new_status=TradeStatus.APPROVED,
            changed_by=current_user.id
        )
    )
    db.commit()

    create_ledger_entry(
        db=db,
        entity_type="TRADE",
        entity_id=trade.id,
        action="APPROVE",
        extra_data={"new_status": TradeStatus.APPROVED}
    )

    return {"message": "Trade approved"}


# =========================================================
# REJECT TRADE (BANK)
# =========================================================
@router.post("/{trade_id}/reject")
def reject_trade(
    trade_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if current_user.role != "bank":
        raise HTTPException(403, "Only bank users allowed")

    trade = db.query(Trades).filter(Trades.id == trade_id).first()
    if not trade:
        raise HTTPException(404, "Trade not found")

    validate_status_transition(trade.status, TradeStatus.REJECTED)

    old_status = trade.status
    trade.status = TradeStatus.REJECTED
    db.commit()

    db.add(
        TradeStatusLogs(
            trade_id=trade.id,
            old_status=old_status,
            new_status=TradeStatus.REJECTED,
            changed_by=current_user.id
        )
    )
    db.commit()

    create_ledger_entry(
        db=db,
        entity_type="TRADE",
        entity_id=trade.id,
        action="REJECT",
        extra_data={"new_status": TradeStatus.REJECTED}
    )

    return {"message": "Trade rejected"}


# =========================================================
# FUND TRADE (BANK)
# =========================================================
@router.post("/{trade_id}/fund")
def fund_trade(
    trade_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if current_user.role != "bank":
        raise HTTPException(403, "Only bank users allowed")

    trade = db.query(Trades).filter(Trades.id == trade_id).first()
    if not trade:
        raise HTTPException(404, "Trade not found")

    validate_status_transition(trade.status, TradeStatus.FUNDED)

    old_status = trade.status
    trade.status = TradeStatus.FUNDED
    db.commit()

    db.add(
        TradeStatusLogs(
            trade_id=trade.id,
            old_status=old_status,
            new_status=TradeStatus.FUNDED,
            changed_by=current_user.id
        )
    )
    db.commit()

    create_ledger_entry(
        db=db,
        entity_type="TRADE",
        entity_id=trade.id,
        action="FUND",
        extra_data={"new_status": TradeStatus.FUNDED}
    )

    return {"message": "Trade funded successfully"}





