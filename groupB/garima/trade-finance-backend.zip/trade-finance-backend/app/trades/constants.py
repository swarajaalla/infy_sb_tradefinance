from enum import Enum

class TradeStatus(str, Enum):
    CREATED = "CREATED"
    DOCUMENTS_UPLOADED = "DOCUMENTS_UPLOADED"
    SUBMITTED = "SUBMITTED"
    VERIFIED = "VERIFIED"
    APPROVED = "APPROVED"
    SETTLED = "SETTLED"
    REJECTED = "REJECTED"



