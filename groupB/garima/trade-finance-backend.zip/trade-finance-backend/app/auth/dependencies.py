from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.auth.jwt_handler import verify_access_token
from app.models import Users

security = HTTPBearer()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_current_user(
    token=Depends(security),
    db: Session = Depends(get_db)
):
    payload = verify_access_token(token.credentials)

    user = db.query(Users).filter(Users.id == payload["user_id"]).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return user
