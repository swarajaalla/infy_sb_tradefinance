from datetime import datetime, timedelta
from jose import jwt, JWTError
from fastapi import HTTPException, status
from ..config import settings

# -------------------------------------------------------
# Create Access Token
# -------------------------------------------------------
def create_access_token(data: dict):
    if "user_id" not in data:
        raise ValueError("user_id must be present in token data")

    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(
        minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
    )
    to_encode.update({"exp": expire})

    token = jwt.encode(
        to_encode,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM
    )
    return token


# -------------------------------------------------------
# Verify Access Token
# -------------------------------------------------------
def verify_access_token(token: str):
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM]
        )

        user_id = payload.get("user_id")
        if user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token payload"
            )

        return payload

    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token"
        )

