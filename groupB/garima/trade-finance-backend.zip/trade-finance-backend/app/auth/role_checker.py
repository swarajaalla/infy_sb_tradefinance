from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from app.auth.jwt_handler import verify_access_token

security = HTTPBearer()

def require_roles(allowed_roles: list):
    def role_checker(
        credentials: HTTPAuthorizationCredentials = Depends(security)
    ):
        payload = verify_access_token(credentials.credentials)

        user_role = payload.get("role")
        if user_role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You are not allowed to perform this action"
            )

        return payload   # optional: return payload if needed

    return role_checker

