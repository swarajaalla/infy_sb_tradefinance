from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from passlib.context import CryptContext
from fastapi.security import HTTPBearer

from ..database import SessionLocal
from ..models import Users
from ..schemas import UserCreate, UserResponse, UserLogin
from .jwt_handler import create_access_token, verify_access_token

router = APIRouter(prefix="/auth", tags=["Auth"])


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()   # <-- ONLY THIS USED


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# -----------------------------------------------------
# REGISTER
# -----------------------------------------------------
@router.post("/register", response_model=UserResponse)
def register_user(user: UserCreate, db: Session = Depends(get_db)):
    existing = db.query(Users).filter(Users.email == user.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    hashed_pw = pwd_context.hash(user.password)

    new_user = Users(
        name=user.name,
        email=user.email,
        password=hashed_pw,
        role=user.role,
        org_name=user.org_name
    )

    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user


# -----------------------------------------------------
# LOGIN
# -----------------------------------------------------
@router.post("/login")
def login(user_credentials: UserLogin, db: Session = Depends(get_db)):
    user = db.query(Users).filter(Users.email == user_credentials.email).first()

    if not user:
        raise HTTPException(status_code=403, detail="Invalid Credentials")

    if not pwd_context.verify(user_credentials.password, user.password):
        raise HTTPException(status_code=403, detail="Incorrect Password")

    access_token = create_access_token({"user_id": user.id})

    return {"access_token": access_token, "token_type": "bearer"}


# -----------------------------------------------------
# GET CURRENT USER  (ONLY HTTPBearer USED)
# -----------------------------------------------------
@router.get("/me")
def get_current_user(token = Depends(security),
                     db: Session = Depends(get_db)):

    payload = verify_access_token(token.credentials)
    user = db.query(Users).filter(Users.id == payload["user_id"]).first()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return user


# -----------------------------------------------------
# ROLE CHECKER
# -----------------------------------------------------
def require_role(allowed_roles: list):
    def role_checker(
        token = Depends(security),
        db: Session = Depends(get_db)
    ):
        payload = verify_access_token(token.credentials)
        user = db.query(Users).filter(Users.id == payload["user_id"]).first()

        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # 🔥 FINAL FIX (PostgreSQL ENUM)
        if user.role.value not in allowed_roles:
            raise HTTPException(status_code=403, detail="Access denied")

        return user

    return role_checker



# -----------------------------------------------------
# PROTECTED ROUTES
# -----------------------------------------------------
@router.get("/admin-area")
def admin_area(current_user = Depends(require_role(["admin"]))):
    return {"message": "Admin area accessed", "user": current_user.email}


@router.get("/bank-area")
def bank_area(current_user = Depends(require_role(["bank"]))):
    return {"message": "Bank area accessed", "user": current_user.email}
