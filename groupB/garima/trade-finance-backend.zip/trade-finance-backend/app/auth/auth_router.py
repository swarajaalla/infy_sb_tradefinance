from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from passlib.context import CryptContext
from fastapi.security import HTTPBearer
from app.database import SessionLocal
from app.models import User, UserRole
# LoginResponse ko bhi import kiya
from app.schemas import UserCreate, UserResponse, UserLogin, LoginResponse
from app.auth.jwt_handler import create_access_token, verify_access_token

router = APIRouter(tags=["Auth"])
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/register", response_model=UserResponse)
def register_user(user: UserCreate, db: Session = Depends(get_db)):
    existing_user = db.query(User).filter(User.email == user.email).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    new_user = User(
        name=user.name,
        email=user.email,
        password=pwd_context.hash(user.password),
        role=user.role.value, # value use karein enum se
        org_name=user.org_name
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

@router.post("/login", response_model=LoginResponse)
def login(user_credentials: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == user_credentials.email).first()
    if not user or not pwd_context.verify(user_credentials.password, user.password):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    access_token = create_access_token({
        "user_id": user.id,
        "role": user.role.value,
        "email": user.email
    })
    return {
        "access_token": access_token, 
        "token_type": "bearer", 
        "role": user.role.value, 
        "name": user.name
    }

# ---------------- CURRENT USER ----------------
@router.get("/me")
def me(token = Depends(security), db: Session = Depends(get_db)):
    payload = verify_access_token(token.credentials)

    user = db.query(User).filter(User.id == payload["user_id"]).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return user

# ---------------- ROLE CHECK ----------------
def require_role(allowed_roles: list):
    def checker(token = Depends(security), db: Session = Depends(get_db)):
        payload = verify_access_token(token.credentials)

        user = db.query(User).filter(User.id == payload["user_id"]).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        if user.role.value not in allowed_roles:
            raise HTTPException(status_code=403, detail="Access denied")

        return user

    return checker


