import { useEffect, useState } from "react";

const API_BASE = "http://localhost:8000";  // 🔁 changed here

function AuthScreen({ onLoginSuccess, message, setMessage }) {
  const [mode, setMode] = useState("login"); // "login" | "register"
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    role: "corporate",
  });

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setMessage("Registering user...");
    try {
      const res = await fetch(`${API_BASE}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          password: form.password,
          role: form.role,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        setMessage(`❌ ${err.detail || "Registration failed"}`);
        return;
      }

      const data = await res.json();
      setMessage(`✅ Registered: ${data.email}. Now you can login.`);
      setMode("login");
    } catch (err) {
      setMessage("❌ Network error during registration");
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setMessage("Logging in...");
    try {
      const res = await fetch(`${API_BASE}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: form.email,
          password: form.password,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        setMessage(`❌ ${err.detail || "Login failed"}`);
        return;
      }

      const data = await res.json();
      localStorage.setItem("token", data.access_token);
      setMessage("✅ Login successful");
      onLoginSuccess(data.access_token);
    } catch (err) {
      setMessage("❌ Network error during login");
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-slate-800 rounded-2xl shadow-2xl p-6 space-y-5">
        <div className="text-center space-y-1">
          <h1 className="text-2xl font-bold text-white">
            Trade Finance Explorer
          </h1>
          <p className="text-xs text-slate-300">
            Secure portal for trade documents & workflows
          </p>
        </div>

        <div className="flex gap-2 text-sm">
          <button
            onClick={() => {
              setMode("login");
              setMessage("");
            }}
            className={`flex-1 py-2 rounded-xl font-semibold ${
              mode === "login"
                ? "bg-blue-500 text-white"
                : "bg-slate-700 text-slate-200 hover:bg-slate-600"
            }`}
          >
            Login
          </button>
          <button
            onClick={() => {
              setMode("register");
              setMessage("");
            }}
            className={`flex-1 py-2 rounded-xl font-semibold ${
              mode === "register"
                ? "bg-blue-500 text-white"
                : "bg-slate-700 text-slate-200 hover:bg-slate-600"
            }`}
          >
            Register
          </button>
        </div>

        {mode === "register" && (
          <form onSubmit={handleRegister} className="space-y-3 text-sm">
            <div>
              <label className="block text-slate-200 mb-1">Full Name</label>
              <input
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-600 text-sm text-white"
                type="text"
                name="name"
                placeholder="Enter your full name"
                value={form.name}
                onChange={handleChange}
                required
              />
            </div>
            <div>
              <label className="block text-slate-200 mb-1">Email</label>
              <input
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-600 text-sm text-white"
                type="email"
                name="email"
                placeholder="you@example.com"
                value={form.email}
                onChange={handleChange}
                required
              />
            </div>
            <div>
              <label className="block text-slate-200 mb-1">Password</label>
              <input
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-600 text-sm text-white"
                type="password"
                name="password"
                placeholder="Choose a strong password"
                value={form.password}
                onChange={handleChange}
                required
              />
            </div>
            <div>
              <label className="block text-slate-200 mb-1">Role</label>
              <select
                name="role"
                value={form.role}
                onChange={handleChange}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-600 text-sm text-white"
              >
                <option value="corporate">Corporate</option>
                <option value="bank">Bank</option>
                <option value="auditor">Auditor</option>
                <option value="admin">Admin</option>
              </select>
            </div>
            <button
              type="submit"
              className="w-full py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold"
            >
              Create Account
            </button>
          </form>
        )}

        {mode === "login" && (
          <form onSubmit={handleLogin} className="space-y-3 text-sm">
            <div>
              <label className="block text-slate-200 mb-1">Email</label>
              <input
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-600 text-sm text-white"
                type="email"
                name="email"
                placeholder="you@example.com"
                value={form.email}
                onChange={handleChange}
                required
              />
            </div>
            <div>
              <label className="block text-slate-200 mb-1">Password</label>
              <input
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-600 text-sm text-white"
                type="password"
                name="password"
                placeholder="Enter your password"
                value={form.password}
                onChange={handleChange}
                required
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 rounded-xl bg-blue-500 hover:bg-blue-600 text-white font-semibold"
            >
              Login
            </button>
          </form>
        )}

        {message && (
          <p className="text-xs text-amber-300 border border-amber-500/40 rounded-lg p-2 bg-black/20">
            {message}
          </p>
        )}
      </div>
    </div>
  );
}

function Dashboard({ onLogout, message, setMessage }) {
  const [docs, setDocs] = useState([]);
  const [docForm, setDocForm] = useState({
    doc_type: "INVOICE",
    doc_number: "",
    file: null,
  });
  const [loadingDocs, setLoadingDocs] = useState(false);
  const [uploading, setUploading] = useState(false);

  const fetchDocuments = async () => {
    setLoadingDocs(true);
    setMessage("");
    try {
      const res = await fetch(`${API_BASE}/documents/my`);
      if (!res.ok) {
        const err = await res.json();
        setMessage(`❌ Error loading documents: ${err.detail || "failed"}`);
        setLoadingDocs(false);
        return;
      }
      const data = await res.json();
      setDocs(data);
    } catch (err) {
      setMessage("❌ Network error while loading documents");
    } finally {
      setLoadingDocs(false);
    }
  };

  useEffect(() => {
    fetchDocuments();
  }, []);

  const handleDocChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "file") {
      setDocForm((prev) => ({ ...prev, file: files[0] || null }));
    } else {
      setDocForm((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!docForm.file) {
      setMessage("Please select a file to upload");
      return;
    }
    setUploading(true);
    setMessage("Uploading document...");

    try {
      const fd = new FormData();
      fd.append("doc_type", docForm.doc_type);
      fd.append("doc_number", docForm.doc_number);
      fd.append("file", docForm.file);

      const res = await fetch(`${API_BASE}/documents/upload`, {
        method: "POST",
        body: fd,
      });

      if (!res.ok) {
        const err = await res.json();
        setMessage(`❌ Upload failed: ${err.detail || "error"}`);
        setUploading(false);
        return;
      }

      const data = await res.json();
      setMessage(`✅ Uploaded: {data.doc_number}`);
      setDocForm({
        doc_type: "INVOICE",
        doc_number: "",
        file: null,
      });
      fetchDocuments();
    } catch (err) {
      setMessage("❌ Network error during upload");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center px-4">
      <div className="w-full max-w-4xl bg-slate-800 rounded-2xl shadow-2xl p-6 space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl md:text-2xl font-bold">
              Trade Finance Dashboard
            </h1>
            <p className="text-xs text-slate-300">
              Manage your trade documents in one secure place
            </p>
          </div>
          <button
            onClick={onLogout}
            className="px-4 py-2 rounded-xl bg-red-500 hover:bg-red-600 text-xs md:text-sm font-semibold"
          >
            Logout
          </button>
        </div>

        {message && (
          <p className="text-xs text-emerald-300 border border-emerald-500/40 rounded-lg p-2 bg-black/20">
            {message}
          </p>
        )}

        {/* Upload Card */}
        <div className="bg-slate-900/70 rounded-xl p-4 space-y-3">
          <h2 className="text-lg font-semibold">Upload New Document</h2>
          <form
            onSubmit={handleUpload}
            className="grid gap-3 md:grid-cols-4 items-end text-sm"
          >
            <div className="md:col-span-1">
              <label className="block text-slate-200 mb-1">Type</label>
              <select
                name="doc_type"
                value={docForm.doc_type}
                onChange={handleDocChange}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-600 text-sm text-white"
              >
                <option value="INVOICE">Invoice</option>
                <option value="LOC">Letter of Credit</option>
                <option value="BILL_OF_LADING">Bill of Lading</option>
                <option value="PO">Purchase Order</option>
                <option value="COO">Certificate of Origin</option>
                <option value="INSURANCE_CERT">Insurance Certificate</option>
              </select>
            </div>
            <div className="md:col-span-1">
              <label className="block text-slate-200 mb-1">Document No.</label>
              <input
                name="doc_number"
                value={docForm.doc_number}
                onChange={handleDocChange}
                placeholder="e.g. INV-001"
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-600 text-sm text-white"
                required
              />
            </div>
            <div className="md:col-span-1">
              <label className="block text-slate-200 mb-1">File</label>
              <input
                type="file"
                name="file"
                onChange={handleDocChange}
                className="w-full text-xs"
                required
              />
            </div>
            <div className="md:col-span-1 flex justify-end">
              <button
                type="submit"
                disabled={uploading}
                className="w-full md:w-auto px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-xs md:text-sm font-semibold disabled:opacity-60"
              >
                {uploading ? "Uploading..." : "Upload"}
              </button>
            </div>
          </form>
        </div>

        {/* Documents List */}
        <div className="bg-slate-900/70 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">My Documents</h2>
            <button
              onClick={fetchDocuments}
              className="px-3 py-1 rounded-lg bg-slate-700 hover:bg-slate-600 text-xs font-semibold"
            >
              Refresh
            </button>
          </div>

          {loadingDocs ? (
            <p className="text-sm text-slate-300">Loading documents...</p>
          ) : docs.length === 0 ? (
            <p className="text-sm text-slate-400">
              No documents yet. Upload your first document above.
            </p>
          ) : (
            <div className="space-y-2 max-h-64 overflow-auto">
              {docs.map((doc) => (
                <div
                  key={doc.id}
                  className="flex items-center justify-between bg-slate-800/80 px-3 py-2 rounded-lg text-sm"
                >
                  <div>
                    <p className="font-semibold">
                      {doc.doc_type} — {doc.doc_number}
                    </p>
                    <p className="text-xs text-slate-400">
                      ID: {doc.id} • Hash: {doc.hash}
                    </p>
                  </div>
                  <a
                    href={`${API_BASE}/documents/download/${doc.id}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs px-3 py-1 rounded-lg bg-blue-500 hover:bg-blue-600"
                  >
                    Download
                  </a>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [token, setToken] = useState(() => localStorage.getItem("token") || "");
  const [message, setMessage] = useState("");

  const handleLoginSuccess = (t) => {
    setToken(t);
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    setToken("");
    setMessage("Logged out");
  };

  if (!token) {
    return (
      <AuthScreen
        onLoginSuccess={handleLoginSuccess}
        message={message}
        setMessage={setMessage}
      />
    );
  }

  return (
    <Dashboard onLogout={handleLogout} message={message} setMessage={setMessage} />
  );
}
