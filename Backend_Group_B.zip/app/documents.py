import os
from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends, UploadFile, File, HTTPException, Form
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from .database import get_db
from .models import Document, DocumentType, User

UPLOAD_DIR = "uploaded_docs"
os.makedirs(UPLOAD_DIR, exist_ok=True)

router = APIRouter(prefix="/documents", tags=["Documents"])


def get_current_user(db: Session = Depends(get_db)):
    # ⚠️ TEMP: just pick first user as "logged in" (for now)
    user = db.query(User).first()
    if not user:
        raise HTTPException(status_code=400, detail="No users found. Register one first.")
    return user


@router.post("/upload")
async def upload_document(
    doc_type: DocumentType = Form(...),
    doc_number: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Save file to local folder
    timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    filename = f"{current_user.id}_{timestamp}_{file.filename}"
    file_path = os.path.join(UPLOAD_DIR, filename)

    with open(file_path, "wb") as f:
        f.write(await file.read())

    # Very simple "hash": in real system use SHA256
    file_hash = f"hash-{timestamp}-{current_user.id}"

    doc = Document(
        owner_id=current_user.id,
        doc_type=doc_type,
        doc_number=doc_number,
        file_url=file_path,
        hash=file_hash,
        issued_at=datetime.utcnow(),
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)

    return {
        "id": doc.id,
        "doc_type": doc.doc_type,
        "doc_number": doc.doc_number,
        "file_url": doc.file_url,
        "hash": doc.hash,
    }


@router.get("/my")
def list_my_documents(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    docs = (
        db.query(Document)
        .filter(Document.owner_id == current_user.id)
        .order_by(Document.created_at.desc())
        .all()
    )
    return docs


@router.get("/download/{doc_id}")
def download_document(
    doc_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    doc = (
        db.query(Document)
        .filter(Document.id == doc_id, Document.owner_id == current_user.id)
        .first()
    )
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    if not os.path.exists(doc.file_url):
        raise HTTPException(status_code=404, detail="File missing on server")

    return FileResponse(doc.file_url, filename=os.path.basename(doc.file_url))
