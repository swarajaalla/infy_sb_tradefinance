from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from fastapi.middleware.cors import CORSMiddleware

from .database import Base, engine, get_db
from . import models
from .auth import router as auth_router
from .documents import router as documents_router


# Create all tables in SQLite (trade_finance.db)
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Trade Finance Blockchain Explorer")


# ---------- CORS (allow frontend to call backend) ----------
origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------- Include Routers ----------
app.include_router(auth_router)        # /auth/register, /auth/login
app.include_router(documents_router)   # /documents/...


# ---------- Basic Endpoints ----------

@app.get("/")
def home():
    return {"message": "Backend Running Successfully ✔"}


@app.get("/db-test")
def db_test(db: Session = Depends(get_db)):
    """
    Simple database check endpoint.
    If this returns status=ok, DB & models are fine.
    """
    return {"status": "ok", "detail": "Database connection works and tables exist."}
